/**
 * Union Foods - Main Application Logic & Feature Orchestration (main.js)
 * Pure Vanilla JavaScript ES6+
 */

document.addEventListener('DOMContentLoaded', () => {
  // --------------------------------------------------------------------------
  // 1. Preloader Fadeout
  // --------------------------------------------------------------------------
  const preloader = document.getElementById('preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        preloader.classList.add('hidden');
      }, 300);
    });
    // Fallback timer if load event already fired
    setTimeout(() => {
      if (!preloader.classList.contains('hidden')) {
        preloader.classList.add('hidden');
      }
    }, 1500);
  }

  // --------------------------------------------------------------------------
  // 2. Dark & Light Theme Mode
  // --------------------------------------------------------------------------
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const storedTheme = localStorage.getItem('union_foods_theme') || 'light';

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('union_foods_theme', theme);

    if (themeToggleBtn) {
      themeToggleBtn.innerHTML = theme === 'dark' 
        ? '<i class="fa-solid fa-sun"></i>' 
        : '<i class="fa-solid fa-moon"></i>';
      themeToggleBtn.setAttribute('title', theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode');
    }
  }

  setTheme(storedTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const target = current === 'dark' ? 'light' : 'dark';
      setTheme(target);
      if (window.unionToast) {
        window.unionToast('Theme Changed', `Switched to ${target === 'dark' ? 'Dark' : 'Light'} appearance.`, 'info', 2000);
      }
    });
  }

  // --------------------------------------------------------------------------
  // 3. Sticky Navigation Header & Back-to-Top Button
  // --------------------------------------------------------------------------
  const siteHeader = document.querySelector('.site-header');
  const backToTopBtn = document.getElementById('backToTop');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;

    if (siteHeader) {
      if (scrollY > 40) {
        siteHeader.classList.add('scrolled');
      } else {
        siteHeader.classList.remove('scrolled');
      }
    }

    if (backToTopBtn) {
      if (scrollY > 350) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }
  });

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // --------------------------------------------------------------------------
  // 4. Mobile Navigation Drawer
  // --------------------------------------------------------------------------
  const mobileToggle = document.getElementById('mobileToggle');
  const navMenu = document.getElementById('navMenu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', !isExpanded);
      navMenu.classList.toggle('active');
      document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        mobileToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });

    document.addEventListener('click', (e) => {
      if (!navMenu.contains(e.target) && !mobileToggle.contains(e.target) && navMenu.classList.contains('active')) {
        navMenu.classList.remove('active');
        mobileToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (navMenu.classList.contains('active')) {
          navMenu.classList.remove('active');
          mobileToggle.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        }
        window.closeModal();
      }
    });
  }

  // --------------------------------------------------------------------------
  // 5. Scroll-Spy Active Link Highlighting
  // --------------------------------------------------------------------------
  const pageSections = document.querySelectorAll('section[id]');
  function updateScrollSpy() {
    const scrollPos = window.pageYOffset + 140;

    pageSections.forEach(section => {
      const top = section.offsetTop;
      const height = section.offsetHeight;
      const id = section.getAttribute('id');
      const navLink = document.querySelector(`.nav-link[href="#${id}"]`);

      if (navLink) {
        if (scrollPos >= top && scrollPos < top + height) {
          navLinks.forEach(l => l.classList.remove('active'));
          navLink.classList.add('active');
        }
      }
    });
  }

  window.addEventListener('scroll', updateScrollSpy);

  // --------------------------------------------------------------------------
  // 6. Live Countdown Timer for Flash Special Offers
  // --------------------------------------------------------------------------
  function initCountdownTimer() {
    // 48 hours from session start or fixed future date
    let targetTime = localStorage.getItem('union_deals_countdown');
    if (!targetTime) {
      targetTime = Date.now() + (2 * 24 * 60 * 60 * 1000) + (14 * 60 * 60 * 1000);
      localStorage.setItem('union_deals_countdown', targetTime);
    } else {
      targetTime = parseInt(targetTime);
    }

    const daysEl = document.getElementById('countDays');
    const hoursEl = document.getElementById('countHours');
    const minsEl = document.getElementById('countMins');
    const secsEl = document.getElementById('countSecs');

    if (!daysEl || !hoursEl || !minsEl || !secsEl) return;

    function update() {
      const now = Date.now();
      const diff = Math.max(0, targetTime - now);

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      daysEl.textContent = String(days).padStart(2, '0');
      hoursEl.textContent = String(hours).padStart(2, '0');
      minsEl.textContent = String(minutes).padStart(2, '0');
      secsEl.textContent = String(seconds).padStart(2, '0');

      if (diff === 0) {
        // Reset timer for demo continuity
        localStorage.setItem('union_deals_countdown', Date.now() + (48 * 3600 * 1000));
      }
    }

    update();
    setInterval(update, 1000);
  }

  initCountdownTimer();

  // --------------------------------------------------------------------------
  // 7. Copy Coupon Voucher Functionality
  // --------------------------------------------------------------------------
  const copyCouponBtn = document.getElementById('btnCopyCoupon');
  if (copyCouponBtn) {
    copyCouponBtn.addEventListener('click', () => {
      const code = copyCouponBtn.getAttribute('data-coupon') || 'UNION25';
      navigator.clipboard.writeText(code).then(() => {
        if (window.unionToast) {
          window.unionToast('Coupon Copied', `Code "${code}" copied to clipboard! Enjoy 25% discount.`, 'success');
        }
        copyCouponBtn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
        setTimeout(() => {
          copyCouponBtn.innerHTML = 'Copy Code';
        }, 2500);
      }).catch(() => {
        if (window.unionToast) window.unionToast('Coupon Code', `Use code: ${code}`, 'info');
      });
    });
  }

  // --------------------------------------------------------------------------
  // 8. Testimonial Carousel Slider
  // --------------------------------------------------------------------------
  function initTestimonialSlider() {
    const slides = document.querySelectorAll('.testimonial-card-slide');
    const prevBtn = document.getElementById('prevTestimonial');
    const nextBtn = document.getElementById('nextTestimonial');
    const dotsContainer = document.getElementById('testimonialDots');

    if (slides.length === 0) return;

    let currentIndex = 0;
    let autoplayTimer = null;

    // Create dots
    if (dotsContainer) {
      dotsContainer.innerHTML = '';
      slides.forEach((_, idx) => {
        const dot = document.createElement('div');
        dot.className = `slider-dot ${idx === 0 ? 'active' : ''}`;
        dot.addEventListener('click', () => goToSlide(idx));
        dotsContainer.appendChild(dot);
      });
    }

    function goToSlide(index) {
      slides.forEach(s => s.classList.remove('active'));
      const dots = dotsContainer ? dotsContainer.querySelectorAll('.slider-dot') : [];
      dots.forEach(d => d.classList.remove('active'));

      currentIndex = (index + slides.length) % slides.length;
      slides[currentIndex].classList.add('active');
      if (dots[currentIndex]) dots[currentIndex].classList.add('active');
    }

    function nextSlide() {
      goToSlide(currentIndex + 1);
    }

    function prevSlide() {
      goToSlide(currentIndex - 1);
    }

    if (nextBtn) nextBtn.addEventListener('click', nextSlide);
    if (prevBtn) prevBtn.addEventListener('click', prevSlide);

    function startAutoplay() {
      stopAutoplay();
      autoplayTimer = setInterval(nextSlide, 5000);
    }

    function stopAutoplay() {
      if (autoplayTimer) clearInterval(autoplayTimer);
    }

    const sliderWrapper = document.querySelector('.testimonial-slider-container');
    if (sliderWrapper) {
      sliderWrapper.addEventListener('mouseenter', stopAutoplay);
      sliderWrapper.addEventListener('mouseleave', startAutoplay);
    }

    startAutoplay();
  }

  initTestimonialSlider();

  // --------------------------------------------------------------------------
  // 9. Animated Numerical Counters (IntersectionObserver)
  // --------------------------------------------------------------------------
  const counterElements = document.querySelectorAll('.stat-number');
  if ('IntersectionObserver' in window && counterElements.length > 0) {
    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseFloat(el.getAttribute('data-target'));
          const suffix = el.getAttribute('data-suffix') || '';
          const isDec = String(target).includes('.');
          let current = 0;
          const duration = 1600;
          const steps = 50;
          const increment = target / steps;
          const stepTime = duration / steps;

          const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
              current = target;
              clearInterval(timer);
            }
            el.textContent = (isDec ? current.toFixed(1) : Math.floor(current).toLocaleString()) + suffix;
          }, stepTime);

          observer.unobserve(el);
        }
      });
    }, { threshold: 0.25 });

    counterElements.forEach(el => counterObserver.observe(el));
  }

  // --------------------------------------------------------------------------
  // 10. Scroll Reveal Animations
  // --------------------------------------------------------------------------
  function initScrollReveal() {
    const reveals = document.querySelectorAll('.reveal-on-scroll:not(.revealed)');
    if ('IntersectionObserver' in window && reveals.length > 0) {
      const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.1 });

      reveals.forEach(r => revealObserver.observe(r));
    } else {
      reveals.forEach(r => r.classList.add('revealed'));
    }
  }

  window.unionScrollReveal = initScrollReveal;
  initScrollReveal();

  // --------------------------------------------------------------------------
  // 11. Button Ripple Effect
  // --------------------------------------------------------------------------
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn-ripple');
    if (!btn) return;

    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement('span');
    ripple.className = 'ripple-circle';

    const size = Math.max(rect.width, rect.height);
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
    ripple.style.top = `${e.clientY - rect.top - size / 2}px`;

    btn.appendChild(ripple);
    setTimeout(() => {
      if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
    }, 600);
  });

  // --------------------------------------------------------------------------
  // 12. Search Overlay Modal & Autocomplete Suggestions
  // --------------------------------------------------------------------------
  const searchModal = document.getElementById('searchModal');
  const searchTriggers = document.querySelectorAll('.btn-search-trigger');
  const searchInput = document.getElementById('largeSearchInput');
  const searchClearBtn = document.getElementById('btnSearchModalClear');
  const searchCloseBtn = document.getElementById('btnSearchModalClose');
  const suggestionsBox = document.getElementById('searchSuggestionsBox');

  function openSearchModal() {
    if (searchModal) {
      searchModal.classList.add('active');
      if (searchInput) {
        searchInput.value = '';
        setTimeout(() => searchInput.focus(), 150);
      }
      renderSearchSuggestions('');
    }
  }

  function closeSearchModal() {
    if (searchModal) {
      searchModal.classList.remove('active');
    }
  }

  searchTriggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openSearchModal();
    });
  });

  if (searchCloseBtn) searchCloseBtn.addEventListener('click', closeSearchModal);

  if (searchClearBtn && searchInput) {
    searchClearBtn.addEventListener('click', () => {
      searchInput.value = '';
      searchClearBtn.style.display = 'none';
      renderSearchSuggestions('');
      searchInput.focus();
    });
  }

  function renderSearchSuggestions(query) {
    if (!suggestionsBox) return;

    const trimmed = query.trim().toLowerCase();
    let matches = [];

    if (!trimmed) {
      // Show popular search terms
      suggestionsBox.innerHTML = `
        <div style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.25rem;">
          Popular Searches
        </div>
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
          <span class="badge badge-primary search-quick-pill" style="cursor: pointer;">Organic Milk</span>
          <span class="badge badge-accent search-quick-pill" style="cursor: pointer;">Extra Virgin Olive Oil</span>
          <span class="badge badge-primary search-quick-pill" style="cursor: pointer;">Sourdough Bread</span>
          <span class="badge badge-accent search-quick-pill" style="cursor: pointer;">Wild Alaskan Salmon</span>
          <span class="badge badge-primary search-quick-pill" style="cursor: pointer;">Hass Avocados</span>
        </div>
      `;

      suggestionsBox.querySelectorAll('.search-quick-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          executeSearch(pill.textContent.trim());
        });
      });
      return;
    }

    if (window.unionProducts) {
      matches = window.unionProducts.filter(p => 
        p.name.toLowerCase().includes(trimmed) || 
        p.categoryName.toLowerCase().includes(trimmed)
      ).slice(0, 5);
    }

    if (matches.length === 0) {
      suggestionsBox.innerHTML = `
        <div style="padding: 1rem; color: var(--text-muted); font-size: 0.9rem;">
          No matching products found for "${query}". Press Enter to view full catalog.
        </div>
      `;
    } else {
      suggestionsBox.innerHTML = matches.map(m => `
        <div class="search-suggestion-item" data-id="${m.id}" data-name="${m.name}">
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <img src="${m.image}" alt="${m.name}" style="width: 38px; height: 38px; border-radius: var(--radius-sm); object-fit: cover;" />
            <div>
              <div style="font-size: 0.9rem; font-weight: 700; color: var(--text-main);">${m.name}</div>
              <span style="font-size: 0.75rem; color: var(--primary); font-weight: 600;">${m.categoryName}</span>
            </div>
          </div>
          <span style="font-weight: 800; color: var(--primary);">₹${Math.round(m.price).toLocaleString('en-IN')}</span>
        </div>
      `).join('');

      suggestionsBox.querySelectorAll('.search-suggestion-item').forEach(item => {
        item.addEventListener('click', () => {
          const id = parseInt(item.dataset.id);
          closeSearchModal();
          if (window.openQuickView) window.openQuickView(id);
        });
      });
    }
  }

  function executeSearch(query) {
    closeSearchModal();
    const catalogSearch = document.getElementById('catalogSearchInput');
    if (catalogSearch) catalogSearch.value = query;

    const productsSec = document.getElementById('products');
    if (productsSec) productsSec.scrollIntoView({ behavior: 'smooth' });

    if (window.renderProducts) {
      window.renderProducts('all', 'default', query);
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const val = e.target.value;
      if (searchClearBtn) searchClearBtn.style.display = val ? 'block' : 'none';
      renderSearchSuggestions(val);
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        executeSearch(searchInput.value);
      }
    });
  }

  // --------------------------------------------------------------------------
  // 13. Recently Viewed Products Tracker
  // --------------------------------------------------------------------------
  class RecentViewTracker {
    constructor() {
      this.key = 'union_foods_recent';
      this.renderShelf();
    }

    addRecentView(productId) {
      let ids = this.getRecentViews();
      ids = ids.filter(id => id !== productId);
      ids.unshift(productId);
      if (ids.length > 6) ids = ids.slice(0, 6);
      localStorage.setItem(this.key, JSON.stringify(ids));
      this.renderShelf();
    }

    getRecentViews() {
      try {
        const data = localStorage.getItem(this.key);
        return data ? JSON.parse(data) : [1, 8, 20]; // default initial suggestions
      } catch (e) {
        return [1, 8, 20];
      }
    }

    renderShelf() {
      const container = document.getElementById('recentProductsShelf');
      if (!container || !window.unionProducts) return;

      const ids = this.getRecentViews();
      const items = ids.map(id => window.unionProducts.find(p => p.id === id)).filter(Boolean);

      if (items.length === 0) {
        const section = document.getElementById('recentlyViewedSection');
        if (section) section.style.display = 'none';
        return;
      }

      container.innerHTML = items.map(p => `
        <div class="recent-product-card" data-id="${p.id}">
          <div class="recent-img-box">
            <img src="${p.image}" alt="${p.name}" />
          </div>
          <h4 class="recent-title">${p.name}</h4>
          <div class="recent-price">₹${Math.round(p.price).toLocaleString('en-IN')}</div>
        </div>
      `).join('');

      container.querySelectorAll('.recent-product-card').forEach(card => {
        card.addEventListener('click', () => {
          const id = parseInt(card.dataset.id);
          if (window.openQuickView) window.openQuickView(id);
        });
      });
    }
  }

  window.unionTracker = new RecentViewTracker();

  // --------------------------------------------------------------------------
  // 14. Demo User Authentication Modal & Profile State
  // --------------------------------------------------------------------------
  const authModal = document.getElementById('authModal');
  const authTriggers = document.querySelectorAll('.btn-auth-trigger');
  const authCloseBtn = document.getElementById('btnAuthClose');

  function openAuthModal() {
    if (authModal) {
      renderAuthModal();
      authModal.classList.add('active');
      const backdrop = document.getElementById('modalBackdrop');
      if (backdrop) backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  authTriggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openAuthModal();
    });
  });

  function renderAuthModal() {
    const userSession = getUserSession();

    if (userSession) {
      // User is logged in
      authModal.innerHTML = `
        <button type="button" class="btn-modal-close" id="btnAuthInnerClose" aria-label="Close modal">
          <i class="fa-solid fa-xmark"></i>
        </button>
        <div class="auth-container" style="text-align: center;">
          <div style="width: 70px; height: 70px; border-radius: 50%; background: var(--primary-light); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: 0 auto 1.25rem;">
            <i class="fa-solid fa-user-check"></i>
          </div>
          <span class="badge badge-primary">Active Member</span>
          <h2 style="font-size: 1.6rem; font-weight: 800; color: var(--text-main); margin: 0.5rem 0;">Welcome, ${userSession.name}!</h2>
          <p style="color: var(--text-muted); font-size: 0.92rem; margin-bottom: 1.5rem;">${userSession.email}</p>

          <div style="background: var(--bg-alt); padding: 1.25rem; border-radius: var(--radius-md); margin-bottom: 1.5rem; text-align: left; font-size: 0.9rem;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
              <span>Membership Tier:</span>
              <strong style="color: var(--primary);">Fresh Rewards Gold</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span>Harvest Points:</span>
              <strong>420 pts</strong>
            </div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 0.75rem;">
            <button type="button" class="btn btn-outline" id="btnTrackRecentOrders">
              <i class="fa-solid fa-truck-fast"></i>
              <span>View Order History</span>
            </button>
            <button type="button" class="btn btn-secondary btn-sm" id="btnLogoutSession">
              <i class="fa-solid fa-right-from-bracket"></i>
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      `;

      authModal.querySelector('#btnAuthInnerClose').addEventListener('click', window.closeModal);
      authModal.querySelector('#btnTrackRecentOrders').addEventListener('click', () => {
        window.closeModal();
        if (window.unionCart) window.unionCart.openOrderTrackingModal('UF-84920');
      });
      authModal.querySelector('#btnLogoutSession').addEventListener('click', () => {
        logoutUser();
        window.closeModal();
      });
      return;
    }

    // Guest login & registration form
    authModal.innerHTML = `
      <button type="button" class="btn-modal-close" id="btnAuthInnerClose" aria-label="Close modal">
        <i class="fa-solid fa-xmark"></i>
      </button>
      <div class="auth-container">
        <div class="auth-tabs">
          <div class="auth-tab-btn active" id="tabLogin">Sign In</div>
          <div class="auth-tab-btn" id="tabRegister">Create Account</div>
        </div>

        <!-- Login Form -->
        <form id="loginForm">
          <div class="form-group">
            <label class="form-label" for="loginEmail">Email Address</label>
            <input type="email" id="loginEmail" class="form-control" placeholder="john@example.com" value="alex.morrison@unionfoods.com" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="loginPassword">Password</label>
            <div class="password-toggle-wrapper">
              <input type="password" id="loginPassword" class="form-control" placeholder="Enter password" value="••••••••" required />
              <button type="button" class="password-toggle-btn" id="btnToggleLoginPass" aria-label="Toggle password visibility">
                <i class="fa-regular fa-eye"></i>
              </button>
            </div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; font-size: 0.85rem;">
            <label style="display: flex; align-items: center; gap: 0.4rem; cursor: pointer;">
              <input type="checkbox" checked />
              <span>Remember me</span>
            </label>
            <a href="#" style="color: var(--primary); font-weight: 600;" id="btnForgotPass">Forgot Password?</a>
          </div>

          <button type="submit" class="btn btn-primary btn-ripple" style="width: 100%;">
            <span>Sign In to Account</span>
          </button>
        </form>

        <!-- Register Form (Initially Hidden) -->
        <form id="registerForm" style="display: none;">
          <div class="form-group">
            <label class="form-label" for="regName">Full Name</label>
            <input type="text" id="regName" class="form-control" placeholder="Alex Morrison" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="regEmail">Email Address</label>
            <input type="email" id="regEmail" class="form-control" placeholder="alex@example.com" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="regPassword">Password</label>
            <div class="password-toggle-wrapper">
              <input type="password" id="regPassword" class="form-control" placeholder="Minimum 6 characters" required />
              <button type="button" class="password-toggle-btn" id="btnToggleRegPass" aria-label="Toggle password visibility">
                <i class="fa-regular fa-eye"></i>
              </button>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-ripple" style="width: 100%; margin-top: 1rem;">
            <span>Create Free Account</span>
          </button>
        </form>
      </div>
    `;

    authModal.querySelector('#btnAuthInnerClose').addEventListener('click', window.closeModal);

    // Tab switching
    const tabLogin = authModal.querySelector('#tabLogin');
    const tabRegister = authModal.querySelector('#tabRegister');
    const loginForm = authModal.querySelector('#loginForm');
    const registerForm = authModal.querySelector('#registerForm');

    tabLogin.addEventListener('click', () => {
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
      loginForm.style.display = 'block';
      registerForm.style.display = 'none';
    });

    tabRegister.addEventListener('click', () => {
      tabRegister.classList.add('active');
      tabLogin.classList.remove('active');
      loginForm.style.display = 'none';
      registerForm.style.display = 'block';
    });

    // Password visibility toggle
    function bindPassToggle(btnId, inputId) {
      const btn = authModal.querySelector(btnId);
      const input = authModal.querySelector(inputId);
      if (btn && input) {
        btn.addEventListener('click', () => {
          const isPass = input.type === 'password';
          input.type = isPass ? 'text' : 'password';
          btn.innerHTML = isPass ? '<i class="fa-regular fa-eye-slash"></i>' : '<i class="fa-regular fa-eye"></i>';
        });
      }
    }

    bindPassToggle('#btnToggleLoginPass', '#loginPassword');
    bindPassToggle('#btnToggleRegPass', '#regPassword');

    // Submit events
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = loginForm.querySelector('#loginEmail').value.trim();
      loginUser({ name: 'Alex Morrison', email: email || 'alex.morrison@unionfoods.com' });
      window.closeModal();
    });

    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = registerForm.querySelector('#regName').value.trim();
      const email = registerForm.querySelector('#regEmail').value.trim();
      loginUser({ name: name || 'Valued Member', email: email });
      window.closeModal();
    });

    const forgotBtn = authModal.querySelector('#btnForgotPass');
    if (forgotBtn) {
      forgotBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (window.unionToast) window.unionToast('Password Reset', 'Password recovery instructions sent to your email.', 'info');
      });
    }
  }

  function getUserSession() {
    try {
      const data = localStorage.getItem('union_foods_user');
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  function loginUser(userData) {
    localStorage.setItem('union_foods_user', JSON.stringify(userData));
    updateAuthHeaderUI();
    if (window.unionToast) {
      window.unionToast('Welcome Back!', `Signed in as ${userData.name}`, 'success');
    }
  }

  function logoutUser() {
    localStorage.removeItem('union_foods_user');
    updateAuthHeaderUI();
    if (window.unionToast) {
      window.unionToast('Signed Out', 'You have successfully signed out.', 'info');
    }
  }

  function updateAuthHeaderUI() {
    const user = getUserSession();
    const authBtn = document.getElementById('headerUserBtn');
    if (authBtn) {
      if (user) {
        authBtn.innerHTML = '<i class="fa-solid fa-user-check" style="color: var(--primary);"></i>';
        authBtn.setAttribute('title', `Account: ${user.name}`);
      } else {
        authBtn.innerHTML = '<i class="fa-regular fa-user"></i>';
        authBtn.setAttribute('title', 'Sign In / Account');
      }
    }
  }

  updateAuthHeaderUI();

  // --------------------------------------------------------------------------
  // 15. Catalog Toolbar Filtering & Sorting Handlers
  // --------------------------------------------------------------------------
  const filterPills = document.querySelectorAll('.filter-pill');
  const sortSelect = document.getElementById('catalogSortSelect');
  const catalogSearch = document.getElementById('catalogSearchInput');
  const catalogClearBtn = document.getElementById('btnCatalogSearchClear');

  let currentCategory = 'all';
  let currentSort = 'default';
  let currentSearch = '';

  filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
      filterPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentCategory = pill.getAttribute('data-filter');
      if (window.renderProducts) {
        window.renderProducts(currentCategory, currentSort, currentSearch);
      }
    });
  });

  if (sortSelect) {
    sortSelect.addEventListener('change', () => {
      currentSort = sortSelect.value;
      if (window.renderProducts) {
        window.renderProducts(currentCategory, currentSort, currentSearch);
      }
    });
  }

  if (catalogSearch) {
    catalogSearch.addEventListener('input', (e) => {
      currentSearch = e.target.value.trim();
      if (catalogClearBtn) catalogClearBtn.style.display = currentSearch ? 'block' : 'none';
      if (window.renderProducts) {
        window.renderProducts(currentCategory, currentSort, currentSearch);
      }
    });
  }

  if (catalogClearBtn && catalogSearch) {
    catalogClearBtn.addEventListener('click', () => {
      catalogSearch.value = '';
      currentSearch = '';
      catalogClearBtn.style.display = 'none';
      if (window.renderProducts) {
        window.renderProducts(currentCategory, currentSort, '');
      }
      catalogSearch.focus();
    });
  }

  // Category Cards in Category Section click handler
  const categoryCards = document.querySelectorAll('.category-card');
  categoryCards.forEach(card => {
    card.addEventListener('click', () => {
      const cat = card.getAttribute('data-category');
      const targetPill = document.querySelector(`.filter-pill[data-filter="${cat}"]`);
      if (targetPill) {
        targetPill.click();
      }
      const prodSec = document.getElementById('products');
      if (prodSec) prodSec.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // --------------------------------------------------------------------------
  // 16. Initialize Form Validation and Initial Product/Recipe Rendering
  // --------------------------------------------------------------------------
  if (window.initFormValidation) {
    window.initFormValidation();
  }

  if (window.renderProducts) {
    window.renderProducts('all', 'default', '', 'productsGrid');
  }

  if (window.renderRecipes) {
    window.renderRecipes('recipesGrid');
  }
});
