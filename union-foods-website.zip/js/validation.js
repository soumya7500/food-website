/**
 * Union Foods - Form Validation & UI Feedback System (validation.js)
 * Pure Vanilla JavaScript ES6+
 */

// --------------------------------------------------------------------------
// 1. Toast Notification System
// --------------------------------------------------------------------------
function showToast(title, message, type = 'info', duration = 3500) {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = {
    success: 'fa-solid fa-circle-check',
    error: 'fa-solid fa-circle-exclamation',
    warning: 'fa-solid fa-triangle-exclamation',
    info: 'fa-solid fa-circle-info'
  };

  const toast = document.createElement('div');
  toast.className = `toast-item toast-${type}`;
  toast.innerHTML = `
    <div class="toast-icon">
      <i class="${icons[type] || icons.info}"></i>
    </div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-msg">${message}</div>
    </div>
    <button type="button" class="btn-toast-close" style="color: var(--text-light); font-size: 0.9rem;" aria-label="Close notification">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;

  container.appendChild(toast);

  // Close handler
  const closeBtn = toast.querySelector('.btn-toast-close');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      removeToast(toast);
    });
  }

  // Auto-dismiss
  const timer = setTimeout(() => {
    removeToast(toast);
  }, duration);

  function removeToast(el) {
    clearTimeout(timer);
    el.style.animation = 'toastSlideOut 0.3s forwards ease';
    setTimeout(() => {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 300);
  }
}

// --------------------------------------------------------------------------
// 2. Custom Confirmation Dialog
// --------------------------------------------------------------------------
function showConfirmDialog({ title, message, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel }) {
  const modal = document.getElementById('confirmModal');
  const backdrop = document.getElementById('modalBackdrop');
  if (!modal || !backdrop) {
    if (confirm(message)) {
      if (onConfirm) onConfirm();
    } else {
      if (onCancel) onCancel();
    }
    return;
  }

  modal.innerHTML = `
    <div style="padding: 2rem 2.5rem; text-align: center; max-width: 460px; margin: 0 auto;">
      <div style="width: 56px; height: 56px; border-radius: 50%; background: #fee2e2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; margin: 0 auto 1.25rem;">
        <i class="fa-solid fa-triangle-exclamation"></i>
      </div>
      <h3 style="font-size: 1.35rem; font-weight: 800; color: var(--text-main); margin-bottom: 0.5rem;">${title}</h3>
      <p style="color: var(--text-muted); font-size: 0.92rem; line-height: 1.5; margin-bottom: 1.75rem;">${message}</p>
      
      <div style="display: flex; gap: 1rem; justify-content: center;">
        <button type="button" class="btn btn-outline" id="btnConfirmCancel" style="flex: 1;">${cancelText}</button>
        <button type="button" class="btn btn-primary" id="btnConfirmOk" style="flex: 1; background: #dc2626; border-color: #dc2626;">${confirmText}</button>
      </div>
    </div>
  `;

  modal.querySelector('#btnConfirmCancel').addEventListener('click', () => {
    window.closeModal();
    if (onCancel) onCancel();
  });

  modal.querySelector('#btnConfirmOk').addEventListener('click', () => {
    window.closeModal();
    if (onConfirm) onConfirm();
  });

  modal.classList.add('active');
  backdrop.classList.add('active');
  document.body.style.overflow = 'hidden';
}

// --------------------------------------------------------------------------
// 3. Form Validation Engine
// --------------------------------------------------------------------------
const validationRules = {
  email: (val) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val),
  phone: (val) => /^[\d\+\-\(\)\s]{7,20}$/.test(val) || val === '',
  required: (val) => val.trim().length > 0,
  minLength: (val, len) => val.trim().length >= len
};

function validateField(input) {
  const type = input.getAttribute('type');
  const isRequired = input.hasAttribute('required');
  const value = input.value.trim();
  let isValid = true;
  let errorMsg = '';

  if (isRequired && !validationRules.required(value)) {
    isValid = false;
    errorMsg = 'This field is required.';
  } else if (value && type === 'email' && !validationRules.email(value)) {
    isValid = false;
    errorMsg = 'Please enter a valid email address.';
  } else if (value && type === 'tel' && !validationRules.phone(value)) {
    isValid = false;
    errorMsg = 'Please enter a valid phone number.';
  }

  // Update UI classes
  if (!isValid) {
    input.classList.add('is-invalid');
    input.classList.remove('is-valid');
    let errElem = input.parentElement.querySelector('.form-error-msg');
    if (!errElem) {
      errElem = document.createElement('div');
      errElem.className = 'form-error-msg';
      input.parentElement.appendChild(errElem);
    }
    errElem.textContent = errorMsg;
    errElem.style.display = 'block';
  } else {
    input.classList.remove('is-invalid');
    if (value) input.classList.add('is-valid');
    const errElem = input.parentElement.querySelector('.form-error-msg');
    if (errElem) errElem.style.display = 'none';
  }

  return isValid;
}

// Initialize form validation listeners
function initFormValidation() {
  // Contact Form
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    const inputs = contactForm.querySelectorAll('input, textarea');
    inputs.forEach(input => {
      input.addEventListener('blur', () => validateField(input));
      input.addEventListener('input', () => {
        if (input.classList.contains('is-invalid')) validateField(input);
      });
    });

    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let allValid = true;
      inputs.forEach(input => {
        if (!validateField(input)) allValid = false;
      });

      if (!allValid) {
        showToast('Form Incomplete', 'Please check the highlighted fields and try again.', 'error');
        return;
      }

      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner"></span> Sending Message...';

      setTimeout(() => {
        contactForm.reset();
        inputs.forEach(i => i.classList.remove('is-valid', 'is-invalid'));
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        showToast('Inquiry Transmitted', 'Thank you! A Union Foods representative will get back to you within 24 hours.', 'success', 5000);
      }, 1000);
    });
  }

  // Newsletter Form
  const newsletterForm = document.getElementById('newsletterForm');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = newsletterForm.querySelector('input[type="email"]');
      if (!emailInput) return;

      const email = emailInput.value.trim();
      if (!validationRules.email(email)) {
        showToast('Invalid Email', 'Please enter a valid email address to subscribe.', 'error');
        emailInput.focus();
        return;
      }

      const submitBtn = newsletterForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner"></span>';

      setTimeout(() => {
        emailInput.value = '';
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        showToast('Subscription Confirmed', 'You are now subscribed to Union Foods harvest updates and seasonal offers!', 'success', 4000);
      }, 800);
    });
  }
}

// Global exposure
window.unionToast = showToast;
window.unionConfirm = showConfirmDialog;
window.initFormValidation = initFormValidation;
