/**
 * Union Foods - Shopping Cart, Checkout & Order Tracking (cart.js)
 * Pure Vanilla JavaScript ES6+
 * Currency: Indian Rupee (₹ INR)
 */

class CartManager {
  constructor() {
    this.storageKey = 'union_foods_cart';
    this.couponKey = 'union_foods_coupon';
    this.orderStorageKey = 'union_foods_orders';
    this.freeShippingThreshold = 499.00; // Free Cold-Chain Delivery above ₹499
    this.flatShippingRate = 49.00;        // Flat ₹49 Delivery
    this.taxRate = 0.05;                 // 5% GST on packaged food

    this.cart = this.loadCart();
    this.activeCoupon = this.loadCoupon();

    this.init();
  }

  // Load from localStorage
  loadCart() {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error('Error loading cart from storage', e);
      return [];
    }
  }

  saveCart() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.cart));
    } catch (e) {
      console.error('Error saving cart to storage', e);
    }
    this.updateCartBadges();
    this.renderCartDrawer();
  }

  loadCoupon() {
    try {
      const data = localStorage.getItem(this.couponKey);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  saveCoupon(coupon) {
    this.activeCoupon = coupon;
    if (coupon) {
      localStorage.setItem(this.couponKey, JSON.stringify(coupon));
    } else {
      localStorage.removeItem(this.couponKey);
    }
  }

  init() {
    this.updateCartBadges();
    this.attachDrawerTriggers();
    this.initPreloadedOrders();
  }

  formatMoney(num) {
    return `₹${Math.round(num).toLocaleString('en-IN')}`;
  }

  formatMoneyDecimal(num) {
    return `₹${Number(num).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
  }

  // --------------------------------------------------------------------------
  // Cart CRUD Operations
  // --------------------------------------------------------------------------
  addToCart(productId, quantity = 1) {
    const product = window.unionProducts ? window.unionProducts.find(p => p.id === productId) : null;
    if (!product) return;

    const existingIndex = this.cart.findIndex(item => item.id === productId);

    if (existingIndex > -1) {
      const newQty = this.cart[existingIndex].quantity + quantity;
      if (newQty > product.stockCount) {
        if (window.unionToast) {
          window.unionToast('Stock Limit Reached', `Only ${product.stockCount} units available in stock.`, 'warning');
        }
        this.cart[existingIndex].quantity = product.stockCount;
      } else {
        this.cart[existingIndex].quantity = newQty;
        if (window.unionToast) {
          window.unionToast('Basket Updated', `Updated quantity of ${product.name} to ${this.cart[existingIndex].quantity}`, 'success');
        }
      }
    } else {
      this.cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        unit: product.unit,
        quantity: Math.min(quantity, product.stockCount)
      });
      if (window.unionToast) {
        window.unionToast('Added to Basket', `${product.name} added to your basket.`, 'success');
      }
    }

    this.saveCart();
    this.openCartDrawer();
  }

  removeFromCart(productId) {
    const item = this.cart.find(i => i.id === productId);
    this.cart = this.cart.filter(i => i.id !== productId);
    this.saveCart();

    if (window.unionToast && item) {
      window.unionToast('Item Removed', `${item.name} removed from your basket.`, 'info');
    }
  }

  updateQuantity(productId, quantity) {
    const index = this.cart.findIndex(i => i.id === productId);
    if (index === -1) return;

    const product = window.unionProducts ? window.unionProducts.find(p => p.id === productId) : null;
    const maxStock = product ? product.stockCount : 99;

    if (quantity <= 0) {
      this.removeFromCart(productId);
    } else if (quantity > maxStock) {
      this.cart[index].quantity = maxStock;
      if (window.unionToast) {
        window.unionToast('Stock Limit', `Maximum available stock is ${maxStock}`, 'warning');
      }
      this.saveCart();
    } else {
      this.cart[index].quantity = quantity;
      this.saveCart();
    }
  }

  clearCart() {
    this.cart = [];
    this.saveCoupon(null);
    this.saveCart();
  }

  // --------------------------------------------------------------------------
  // Financial Calculations
  // --------------------------------------------------------------------------
  getSubtotal() {
    return this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  getDiscount() {
    const subtotal = this.getSubtotal();
    if (!this.activeCoupon) return 0;

    if (this.activeCoupon.type === 'percentage') {
      return (subtotal * this.activeCoupon.value) / 100;
    }
    return 0;
  }

  getShipping() {
    const subtotal = this.getSubtotal();
    if (subtotal === 0) return 0;
    if (this.activeCoupon && this.activeCoupon.type === 'freeship') return 0;
    return subtotal >= this.freeShippingThreshold ? 0 : this.flatShippingRate;
  }

  getTax() {
    const discountedSubtotal = Math.max(0, this.getSubtotal() - this.getDiscount());
    return discountedSubtotal * this.taxRate;
  }

  getTotal() {
    const subtotal = this.getSubtotal();
    if (subtotal === 0) return 0;
    const discount = this.getDiscount();
    const shipping = this.getShipping();
    const tax = this.getTax();
    return Math.max(0, subtotal - discount + shipping + tax);
  }

  getTotalItemsCount() {
    return this.cart.reduce((count, item) => count + item.quantity, 0);
  }

  // --------------------------------------------------------------------------
  // Coupon Verification
  // --------------------------------------------------------------------------
  applyCoupon(code) {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      return { success: false, message: 'Please enter a coupon code.' };
    }

    const availableCoupons = {
      'UNION25': { code: 'UNION25', type: 'percentage', value: 25, label: '25% Off Storewide' },
      'FREESHIP': { code: 'FREESHIP', type: 'freeship', value: 0, label: 'Free Cold-Chain Delivery' },
      'WELCOME10': { code: 'WELCOME10', type: 'percentage', value: 10, label: '10% New Customer Discount' }
    };

    if (availableCoupons[cleanCode]) {
      this.saveCoupon(availableCoupons[cleanCode]);
      this.saveCart();
      return { success: true, message: `Coupon "${cleanCode}" applied! ${availableCoupons[cleanCode].label}` };
    } else {
      return { success: false, message: `Coupon "${cleanCode}" is invalid or expired. Try "UNION25"` };
    }
  }

  removeCoupon() {
    this.saveCoupon(null);
    this.saveCart();
  }

  // --------------------------------------------------------------------------
  // UI & Badge Sync
  // --------------------------------------------------------------------------
  updateCartBadges() {
    const count = this.getTotalItemsCount();
    document.querySelectorAll('.cart-badge-count').forEach(el => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  renderCartDrawer() {
    const container = document.getElementById('cartDrawerBody');
    const footerContainer = document.getElementById('cartDrawerFooter');
    const meterContainer = document.getElementById('shippingMeterContainer');

    if (!container) return;

    const subtotal = this.getSubtotal();
    const count = this.getTotalItemsCount();

    // Free shipping meter
    if (meterContainer) {
      if (count === 0) {
        meterContainer.innerHTML = '';
      } else {
        const remaining = Math.max(0, this.freeShippingThreshold - subtotal);
        const percent = Math.min(100, Math.round((subtotal / this.freeShippingThreshold) * 100));

        meterContainer.innerHTML = `
          <div class="shipping-meter-box">
            <div class="shipping-meter-text">
              ${remaining === 0 ? '🎉 You unlocked <strong>FREE Cold-Chain Delivery</strong>!' : `Add <strong>${this.formatMoney(remaining)}</strong> more to get <strong>FREE Delivery</strong>!`}
            </div>
            <div class="shipping-progress-bar">
              <div class="shipping-progress-fill" style="width: ${percent}%;"></div>
            </div>
          </div>
        `;
      }
    }

    // Empty state
    if (this.cart.length === 0) {
      container.innerHTML = `
        <div class="drawer-empty-state">
          <div class="empty-icon"><i class="fa-solid fa-basket-shopping"></i></div>
          <h4 class="empty-title">Your Basket is Empty</h4>
          <p class="empty-desc">Discover our fresh organic harvest and add wholesome goods to your pantry.</p>
          <button type="button" class="btn btn-primary btn-sm btn-close-cart-explore">
            <span>Explore Farm Catalog</span>
            <i class="fa-solid fa-arrow-right"></i>
          </button>
        </div>
      `;
      const exploreBtn = container.querySelector('.btn-close-cart-explore');
      if (exploreBtn) {
        exploreBtn.addEventListener('click', () => {
          this.closeCartDrawer();
          const target = document.getElementById('products');
          if (target) target.scrollIntoView({ behavior: 'smooth' });
        });
      }

      if (footerContainer) footerContainer.innerHTML = '';
      return;
    }

    // Items list
    container.innerHTML = this.cart.map(item => `
      <div class="cart-drawer-item" data-id="${item.id}">
        <img src="${item.image}" alt="${item.name}" class="cart-item-img" />
        <div class="cart-item-info">
          <h4 class="cart-item-name">${item.name}</h4>
          <div class="cart-item-price">${this.formatMoney(item.price * item.quantity)} (${this.formatMoney(item.price)} / ea)</div>
          <div class="cart-qty-controls">
            <button type="button" class="btn-qty btn-cart-qty-minus" data-id="${item.id}"><i class="fa-solid fa-minus"></i></button>
            <span class="qty-display">${item.quantity}</span>
            <button type="button" class="btn-qty btn-cart-qty-plus" data-id="${item.id}"><i class="fa-solid fa-plus"></i></button>
          </div>
        </div>
        <button type="button" class="btn-remove-item btn-cart-remove" data-id="${item.id}" title="Remove item" aria-label="Remove item">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
    `).join('');

    // Attach item buttons
    container.querySelectorAll('.btn-cart-qty-minus').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.id);
        const item = this.cart.find(i => i.id === id);
        if (item) this.updateQuantity(id, item.quantity - 1);
      });
    });

    container.querySelectorAll('.btn-cart-qty-plus').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.id);
        const item = this.cart.find(i => i.id === id);
        if (item) this.updateQuantity(id, item.quantity + 1);
      });
    });

    container.querySelectorAll('.btn-cart-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.id);
        this.removeFromCart(id);
      });
    });

    // Render footer calculations
    if (footerContainer) {
      const discount = this.getDiscount();
      const shipping = this.getShipping();
      const tax = this.getTax();
      const total = this.getTotal();

      footerContainer.innerHTML = `
        <div class="coupon-apply-row" style="margin-bottom: 1rem;">
          ${this.activeCoupon ? `
            <div style="display: flex; align-items: center; justify-content: space-between; background: var(--bg-alt); padding: 0.5rem 0.85rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); font-size: 0.85rem;">
              <span><i class="fa-solid fa-tag" style="color: var(--primary);"></i> <strong>${this.activeCoupon.code}</strong> applied</span>
              <button type="button" id="btnRemoveCoupon" style="color: var(--color-danger); font-size: 0.8rem; font-weight: 700;">Remove</button>
            </div>
          ` : `
            <div style="display: flex; gap: 0.5rem;">
              <input type="text" id="cartCouponInput" placeholder="Coupon (e.g. UNION25)" style="flex-grow: 1; padding: 0.5rem 0.85rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); font-size: 0.85rem; background: var(--bg-input); color: var(--text-main);" />
              <button type="button" class="btn btn-secondary btn-sm" id="btnApplyCartCoupon">Apply</button>
            </div>
          `}
        </div>

        <div class="cart-subtotal-row">
          <span>Subtotal</span>
          <span>${this.formatMoney(subtotal)}</span>
        </div>
        ${discount > 0 ? `
          <div class="cart-subtotal-row" style="color: var(--primary);">
            <span>Discount (${this.activeCoupon.code})</span>
            <span>-${this.formatMoney(discount)}</span>
          </div>
        ` : ''}
        <div class="cart-subtotal-row">
          <span>Cold-Chain Delivery</span>
          <span>${shipping === 0 ? '<strong style="color: var(--color-success);">FREE</strong>' : this.formatMoney(shipping)}</span>
        </div>
        <div class="cart-subtotal-row">
          <span>GST (5% Est.)</span>
          <span>${this.formatMoney(tax)}</span>
        </div>
        <div class="cart-total-row">
          <span>Estimated Total</span>
          <span style="color: var(--primary);">${this.formatMoney(total)}</span>
        </div>

        <div class="drawer-actions">
          <button type="button" class="btn btn-primary btn-ripple" id="btnProceedCheckout" style="width: 100%;">
            <i class="fa-solid fa-lock"></i>
            <span>Proceed to Checkout</span>
          </button>
          <button type="button" class="btn btn-outline btn-sm" id="btnClearEntireCart">
            <i class="fa-solid fa-trash-can"></i>
            <span>Clear Basket</span>
          </button>
        </div>
      `;

      // Attach footer action events
      const applyBtn = footerContainer.querySelector('#btnApplyCartCoupon');
      const couponInput = footerContainer.querySelector('#cartCouponInput');
      const removeCouponBtn = footerContainer.querySelector('#btnRemoveCoupon');
      const checkoutBtn = footerContainer.querySelector('#btnProceedCheckout');
      const clearBtn = footerContainer.querySelector('#btnClearEntireCart');

      if (applyBtn && couponInput) {
        applyBtn.addEventListener('click', () => {
          const res = this.applyCoupon(couponInput.value);
          if (window.unionToast) {
            window.unionToast(res.success ? 'Coupon Applied' : 'Invalid Coupon', res.message, res.success ? 'success' : 'error');
          }
        });
      }

      if (removeCouponBtn) {
        removeCouponBtn.addEventListener('click', () => {
          this.removeCoupon();
          if (window.unionToast) window.unionToast('Coupon Removed', 'Coupon has been cleared.', 'info');
        });
      }

      if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
          this.closeCartDrawer();
          this.openCheckoutModal();
        });
      }

      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          if (window.unionConfirm) {
            window.unionConfirm({
              title: 'Empty Shopping Basket?',
              message: 'Are you sure you want to remove all items from your basket? This action cannot be undone.',
              confirmText: 'Yes, Empty Basket',
              cancelText: 'Keep Items',
              onConfirm: () => {
                this.clearCart();
                if (window.unionToast) window.unionToast('Basket Emptied', 'All items have been removed.', 'info');
              }
            });
          } else {
            this.clearCart();
          }
        });
      }
    }
  }

  // --------------------------------------------------------------------------
  // Drawer Toggling
  // --------------------------------------------------------------------------
  attachDrawerTriggers() {
    const cartToggleBtns = document.querySelectorAll('.btn-cart-toggle');
    const drawer = document.getElementById('cartDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    const closeBtn = document.getElementById('btnCartDrawerClose');

    cartToggleBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openCartDrawer();
      });
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeCartDrawer());
    }

    if (backdrop) {
      backdrop.addEventListener('click', () => {
        this.closeCartDrawer();
        if (window.unionWishlist) window.unionWishlist.closeWishlistDrawer();
      });
    }
  }

  openCartDrawer() {
    const drawer = document.getElementById('cartDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    if (drawer && backdrop) {
      this.renderCartDrawer();
      drawer.classList.add('active');
      backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  closeCartDrawer() {
    const drawer = document.getElementById('cartDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    if (drawer && backdrop) {
      drawer.classList.remove('active');
      backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  // --------------------------------------------------------------------------
  // Checkout Modal & Flow
  // --------------------------------------------------------------------------
  openCheckoutModal() {
    if (this.cart.length === 0) {
      if (window.unionToast) window.unionToast('Cart is Empty', 'Please add items to your cart before proceeding to checkout.', 'warning');
      return;
    }

    const modal = document.getElementById('checkoutModal');
    const backdrop = document.getElementById('modalBackdrop');
    if (!modal || !backdrop) return;

    const subtotal = this.getSubtotal();
    const discount = this.getDiscount();
    const shipping = this.getShipping();
    const tax = this.getTax();
    const total = this.getTotal();

    modal.innerHTML = `
      <button type="button" class="btn-modal-close" id="btnCheckoutClose" aria-label="Close checkout">
        <i class="fa-solid fa-xmark"></i>
      </button>
      <div style="padding: 2.5rem; max-width: 800px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 2rem;">
          <span class="badge badge-primary">Express Cold-Chain Checkout</span>
          <h2 style="font-size: 1.85rem; font-weight: 800; color: var(--text-main); margin-top: 0.5rem;">Complete Your Order</h2>
          <p style="color: var(--text-muted); font-size: 0.95rem;">Enter your delivery destination and payment details.</p>
        </div>

        <form id="checkoutForm" novalidate>
          <div style="display: grid; grid-template-columns: 1.25fr 0.95fr; gap: 2.5rem;" class="checkout-modal-grid">
            <!-- Left: Delivery Information -->
            <div>
              <h4 style="font-size: 1.1rem; font-weight: 700; color: var(--text-main); margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem;">
                1. Customer & Delivery Info
              </h4>

              <div class="form-row">
                <div class="form-group">
                  <label class="form-label" for="coFirstName">First Name *</label>
                  <input type="text" id="coFirstName" class="form-control" placeholder="Aarav" required />
                </div>
                <div class="form-group">
                  <label class="form-label" for="coLastName">Last Name *</label>
                  <input type="text" id="coLastName" class="form-control" placeholder="Sharma" required />
                </div>
              </div>

              <div class="form-row">
                <div class="form-group">
                  <label class="form-label" for="coEmail">Email Address *</label>
                  <input type="email" id="coEmail" class="form-control" placeholder="aarav@example.com" required />
                </div>
                <div class="form-group">
                  <label class="form-label" for="coPhone">Mobile Number *</label>
                  <input type="tel" id="coPhone" class="form-control" placeholder="+91 98765 43210" required />
                </div>
              </div>

              <div class="form-group">
                <label class="form-label" for="coAddress">Delivery Address *</label>
                <input type="text" id="coAddress" class="form-control" placeholder="Flat 402, Green Glen Layout, Bellandur" required />
              </div>

              <div class="form-row">
                <div class="form-group">
                  <label class="form-label" for="coCity">City *</label>
                  <input type="text" id="coCity" class="form-control" placeholder="Bengaluru" required />
                </div>
                <div class="form-group">
                  <label class="form-label" for="coZip">PIN Code *</label>
                  <input type="text" id="coZip" class="form-control" placeholder="560103" required />
                </div>
              </div>

              <h4 style="font-size: 1.1rem; font-weight: 700; color: var(--text-main); margin: 1.5rem 0 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem;">
                2. Payment Method (Demo Simulator)
              </h4>

              <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                <label style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: var(--radius-md); cursor: pointer; background: var(--bg-alt);">
                  <input type="radio" name="paymentMethod" value="upi" checked />
                  <i class="fa-solid fa-qrcode" style="color: var(--primary);"></i>
                  <span style="font-weight: 600; font-size: 0.9rem;">UPI / NetBanking / Cards (Instant Test Pay)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: var(--radius-md); cursor: pointer;">
                  <input type="radio" name="paymentMethod" value="cod" />
                  <i class="fa-solid fa-money-bill-wave" style="color: var(--accent);"></i>
                  <span style="font-weight: 600; font-size: 0.9rem;">Cash on Delivery (Pay on Inspection)</span>
                </label>
              </div>
            </div>

            <!-- Right: Order Summary -->
            <div style="background: var(--bg-alt); padding: 1.5rem; border-radius: var(--radius-lg); border: 1px solid var(--border-color); display: flex; flex-direction: column;">
              <h4 style="font-size: 1.1rem; font-weight: 700; color: var(--text-main); margin-bottom: 1rem;">
                Order Summary (${this.getTotalItemsCount()} items)
              </h4>

              <div style="max-height: 200px; overflow-y: auto; display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1rem; padding-right: 0.25rem;">
                ${this.cart.map(i => `
                  <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.85rem;">
                    <span style="color: var(--text-main); font-weight: 600;">${i.quantity}x ${i.name}</span>
                    <span style="color: var(--primary); font-weight: 700;">${this.formatMoney(i.price * i.quantity)}</span>
                  </div>
                `).join('')}
              </div>

              <div style="border-top: 1px solid var(--border-color); padding-top: 0.75rem; display: flex; flex-direction: column; gap: 0.4rem; font-size: 0.88rem; color: var(--text-muted);">
                <div style="display: flex; justify-content: space-between;">
                  <span>Subtotal</span>
                  <span>${this.formatMoney(subtotal)}</span>
                </div>
                ${discount > 0 ? `
                  <div style="display: flex; justify-content: space-between; color: var(--primary);">
                    <span>Discount</span>
                    <span>-${this.formatMoney(discount)}</span>
                  </div>
                ` : ''}
                <div style="display: flex; justify-content: space-between;">
                  <span>Delivery Fee</span>
                  <span>${shipping === 0 ? '<strong style="color: var(--color-success);">FREE</strong>' : this.formatMoney(shipping)}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                  <span>GST (5%)</span>
                  <span>${this.formatMoney(tax)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: 800; color: var(--text-main); border-top: 1px dashed var(--border-color); padding-top: 0.6rem; margin-top: 0.4rem;">
                  <span>Total Amount</span>
                  <span style="color: var(--primary);">${this.formatMoney(total)}</span>
                </div>
              </div>

              <button type="submit" class="btn btn-primary btn-ripple" id="btnPlaceOrderSubmit" style="width: 100%; margin-top: 1.5rem;">
                <i class="fa-solid fa-check-circle"></i>
                <span>Place Order & Confirm (${this.formatMoney(total)})</span>
              </button>

              <div style="font-size: 0.75rem; color: var(--text-muted); text-align: center; margin-top: 0.75rem; display: flex; align-items: center; justify-content: center; gap: 0.5rem;">
                <i class="fa-solid fa-shield-halved" style="color: var(--primary);"></i>
                <span>256-bit Encrypted Checkout &bull; 100% Guaranteed</span>
              </div>
            </div>
          </div>
        </form>
      </div>
    `;

    modal.querySelector('#btnCheckoutClose').addEventListener('click', () => {
      window.closeModal();
    });

    const form = modal.querySelector('#checkoutForm');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleCheckoutSubmit(form);
    });

    modal.classList.add('active');
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  handleCheckoutSubmit(form) {
    const fName = form.querySelector('#coFirstName').value.trim();
    const lName = form.querySelector('#coLastName').value.trim();
    const email = form.querySelector('#coEmail').value.trim();
    const phone = form.querySelector('#coPhone').value.trim();
    const address = form.querySelector('#coAddress').value.trim();
    const city = form.querySelector('#coCity').value.trim();
    const zip = form.querySelector('#coZip').value.trim();

    if (!fName || !lName || !email || !phone || !address || !city || !zip) {
      if (window.unionToast) window.unionToast('Missing Fields', 'Please complete all required customer and address fields.', 'error');
      return;
    }

    // Submit button state
    const submitBtn = form.querySelector('#btnPlaceOrderSubmit');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span> Processing Order...';

    setTimeout(() => {
      // Generate Order
      const orderId = 'UF-' + Math.floor(10000 + Math.random() * 90000);
      const orderDate = new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
      const estDelivery = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' });

      const newOrder = {
        orderId: orderId,
        date: orderDate,
        estDelivery: estDelivery,
        customer: { name: `${fName} ${lName}`, email, phone, address: `${address}, ${city} - ${zip}` },
        items: [...this.cart],
        subtotal: this.getSubtotal(),
        discount: this.getDiscount(),
        shipping: this.getShipping(),
        tax: this.getTax(),
        total: this.getTotal(),
        status: 'Processing in Cold Chain',
        step: 2
      };

      this.saveNewOrder(newOrder);
      this.clearCart();
      window.closeModal();

      // Show Order Confirmation
      this.openOrderConfirmationModal(newOrder);
    }, 1200);
  }

  saveNewOrder(order) {
    try {
      const orders = this.getOrders();
      orders.unshift(order);
      localStorage.setItem(this.orderStorageKey, JSON.stringify(orders));
    } catch (e) {
      console.error('Failed to save order', e);
    }
  }

  getOrders() {
    try {
      const data = localStorage.getItem(this.orderStorageKey);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  initPreloadedOrders() {
    const existing = this.getOrders();
    if (existing.length === 0) {
      const demoOrders = [
        {
          orderId: 'UF-84920',
          date: 'Yesterday',
          estDelivery: 'Tomorrow, by 2:00 PM',
          customer: { name: 'Pooja Verma', email: 'pooja.verma@example.com', phone: '+91 98450 12345', address: 'B-204, Palm Meadows, Whitefield, Bengaluru - 560066' },
          items: [
            { id: 1, name: 'Organic Hass Avocados', price: 299, quantity: 2 },
            { id: 20, name: 'Extra Virgin Cold-Pressed Olive Oil', price: 899, quantity: 1 }
          ],
          subtotal: 1497,
          discount: 0,
          shipping: 0,
          tax: 74.85,
          total: 1571.85,
          status: 'Out for Delivery',
          step: 3
        }
      ];
      try {
        localStorage.setItem(this.orderStorageKey, JSON.stringify(demoOrders));
      } catch (e) {}
    }
  }

  openOrderConfirmationModal(order) {
    const modal = document.getElementById('orderConfirmModal');
    const backdrop = document.getElementById('modalBackdrop');
    if (!modal || !backdrop) return;

    modal.innerHTML = `
      <div style="padding: 3rem 2.5rem; text-align: center;">
        <div style="width: 72px; height: 72px; border-radius: 50%; background: var(--primary-light); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 2.2rem; margin: 0 auto 1.5rem;">
          <i class="fa-solid fa-check"></i>
        </div>
        <span class="badge badge-primary">Order Confirmed</span>
        <h2 style="font-size: 2rem; font-weight: 800; color: var(--text-main); margin: 0.5rem 0;">Thank You for Your Order!</h2>
        <p style="color: var(--text-muted); font-size: 1rem; max-width: 520px; margin: 0 auto 1.5rem;">
          Your order has been received and routed to our temperature-controlled dispatch hub.
        </p>

        <div style="background: var(--bg-alt); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.25rem; max-width: 480px; margin: 0 auto 2rem; text-align: left;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-size: 0.9rem;">
            <span style="color: var(--text-muted);">Order Tracking ID:</span>
            <strong style="color: var(--primary); font-size: 1.05rem;">${order.orderId}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-size: 0.9rem;">
            <span style="color: var(--text-muted);">Estimated Fresh Delivery:</span>
            <strong>${order.estDelivery}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.9rem;">
            <span style="color: var(--text-muted);">Total Paid:</span>
            <strong style="color: var(--text-main);">${this.formatMoney(order.total)}</strong>
          </div>
        </div>

        <div style="display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;">
          <button type="button" class="btn btn-primary" id="btnTrackConfirmedOrder" data-id="${order.orderId}">
            <i class="fa-solid fa-truck-fast"></i>
            <span>Track Order Status</span>
          </button>
          <button type="button" class="btn btn-outline" id="btnCloseOrderConfirm">
            <span>Continue Shopping</span>
          </button>
        </div>
      </div>
    `;

    modal.querySelector('#btnTrackConfirmedOrder').addEventListener('click', () => {
      window.closeModal();
      this.openOrderTrackingModal(order.orderId);
    });

    modal.querySelector('#btnCloseOrderConfirm').addEventListener('click', () => {
      window.closeModal();
    });

    modal.classList.add('active');
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  // --------------------------------------------------------------------------
  // Live Order Tracking
  // --------------------------------------------------------------------------
  openOrderTrackingModal(prefillOrderId = '') {
    const modal = document.getElementById('orderTrackingModal');
    const backdrop = document.getElementById('modalBackdrop');
    if (!modal || !backdrop) return;

    modal.innerHTML = `
      <button type="button" class="btn-modal-close" id="btnTrackingClose" aria-label="Close tracking">
        <i class="fa-solid fa-xmark"></i>
      </button>
      <div style="padding: 2.5rem; max-width: 680px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 2rem;">
          <div style="display: inline-flex; width: 50px; height: 50px; border-radius: 50%; background: var(--primary-light); color: var(--primary); align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 0.75rem;">
            <i class="fa-solid fa-route"></i>
          </div>
          <h2 style="font-size: 1.85rem; font-weight: 800; color: var(--text-main);">Live Cold-Chain Tracking</h2>
          <p style="color: var(--text-muted); font-size: 0.95rem;">Track the real-time fulfillment and temperature status of your shipment.</p>
        </div>

        <div style="display: flex; gap: 0.75rem; max-width: 480px; margin: 0 auto 2rem;">
          <input type="text" id="trackInputId" class="form-control" placeholder="Enter Order ID (e.g. UF-84920)" value="${prefillOrderId}" />
          <button type="button" class="btn btn-primary" id="btnSearchTrack">Track</button>
        </div>

        <div id="trackingResultContainer"></div>
      </div>
    `;

    modal.querySelector('#btnTrackingClose').addEventListener('click', () => {
      window.closeModal();
    });

    const searchBtn = modal.querySelector('#btnSearchTrack');
    const input = modal.querySelector('#trackInputId');

    const runLookup = () => {
      const q = input.value.trim().toUpperCase();
      this.renderTrackingResult(q, modal.querySelector('#trackingResultContainer'));
    };

    searchBtn.addEventListener('click', runLookup);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') runLookup();
    });

    if (prefillOrderId) {
      runLookup();
    }

    modal.classList.add('active');
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  renderTrackingResult(orderId, container) {
    if (!orderId) {
      container.innerHTML = '<p style="text-align: center; color: var(--text-muted);">Please enter an Order Tracking Number.</p>';
      return;
    }

    const orders = this.getOrders();
    const order = orders.find(o => o.orderId.toUpperCase() === orderId);

    if (!order) {
      container.innerHTML = `
        <div style="text-align: center; padding: 2rem; background: var(--bg-alt); border-radius: var(--radius-md); border: 1px solid var(--border-color);">
          <i class="fa-solid fa-triangle-exclamation" style="font-size: 2rem; color: var(--color-warning); margin-bottom: 0.5rem;"></i>
          <h4 style="font-weight: 700; color: var(--text-main);">Order Not Found</h4>
          <p style="color: var(--text-muted); font-size: 0.88rem;">We couldn't locate order "${orderId}". Try using demo order <strong>UF-84920</strong>.</p>
        </div>
      `;
      return;
    }

    const step = order.step || 2;

    container.innerHTML = `
      <div style="background: var(--bg-alt); border-radius: var(--radius-lg); padding: 1.75rem; border: 1px solid var(--border-color);">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.5rem;">
          <div>
            <h4 style="font-size: 1.15rem; font-weight: 800; color: var(--text-main);">${order.orderId}</h4>
            <span style="font-size: 0.82rem; color: var(--text-muted);">Recipient: ${order.customer.name}</span>
          </div>
          <div style="text-align: right;">
            <span class="badge badge-primary">${order.status}</span>
            <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.25rem;">Est: ${order.estDelivery}</div>
          </div>
        </div>

        <!-- 4 Step Tracker Visual -->
        <div class="tracking-stepper">
          <div class="tracking-progress-fill" style="width: ${(step - 1) * 33.33}%;"></div>
          
          <div class="step-item ${step >= 1 ? (step === 1 ? 'active' : 'completed') : ''}">
            <div class="step-circle"><i class="fa-solid fa-receipt"></i></div>
            <span class="step-label">Order Placed</span>
          </div>

          <div class="step-item ${step >= 2 ? (step === 2 ? 'active' : 'completed') : ''}">
            <div class="step-circle"><i class="fa-solid fa-snowflake"></i></div>
            <span class="step-label">Cold Storage Packing</span>
          </div>

          <div class="step-item ${step >= 3 ? (step === 3 ? 'active' : 'completed') : ''}">
            <div class="step-circle"><i class="fa-solid fa-truck"></i></div>
            <span class="step-label">Out for Delivery</span>
          </div>

          <div class="step-item ${step >= 4 ? (step === 4 ? 'active' : 'completed') : ''}">
            <div class="step-circle"><i class="fa-solid fa-house-chimney"></i></div>
            <span class="step-label">Delivered Fresh</span>
          </div>
        </div>

        <div style="margin-top: 1.5rem; background: var(--bg-surface); padding: 1rem; border-radius: var(--radius-md); font-size: 0.85rem; border: 1px solid var(--border-color);">
          <div style="font-weight: 700; color: var(--text-main); margin-bottom: 0.35rem;">Logistics Sensor Verification:</div>
          <div style="color: var(--color-success);"><i class="fa-solid fa-temperature-arrow-down"></i> Active Refrigeration: 3.8&deg;C (Optimal)</div>
          <div style="color: var(--text-muted); margin-top: 0.25rem;">Delivery Destination: ${order.customer.address}</div>
        </div>
      </div>
    `;
  }
}

// Instantiate globally
window.unionCart = new CartManager();
