/**
 * Union Foods - Products & Recipes Data & Rendering Engine (products.js)
 * Pure Vanilla JavaScript ES6+
 * Currency: Indian Rupee (₹ INR)
 */

// Global currency symbol helper
const CURRENCY_SYMBOL = '₹';

function formatPrice(amount) {
  return `${CURRENCY_SYMBOL}${Math.round(amount).toLocaleString('en-IN')}`;
}

function formatPriceDecimal(amount) {
  return `${CURRENCY_SYMBOL}${Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

// --------------------------------------------------------------------------
// 1. Comprehensive Product Catalog in Indian Rupees (₹)
// --------------------------------------------------------------------------
const unionProducts = [
  // Fresh Foods
  {
    id: 1,
    name: "Organic Hass Avocados",
    category: "fresh",
    categoryName: "Fresh Foods",
    badge: "Organic",
    badgeType: "primary",
    price: 299,
    originalPrice: 399,
    rating: 4.9,
    reviews: 184,
    inStock: true,
    stockCount: 42,
    unit: "4-pack pack",
    image: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&w=600&q=80",
    description: "Creamy, nutrient-dense California Hass avocados hand-picked at peak maturity. Ideal for fresh guacamole, salads, and morning toast.",
    origin: "San Diego Organic Orchards",
    shelfLife: "7-10 Days",
    certifications: "Jaivik Bharat, USDA Organic"
  },
  {
    id: 2,
    name: "Crisp Royal Gala Apples",
    category: "fresh",
    categoryName: "Fresh Foods",
    badge: "Fresh Pick",
    badgeType: "new",
    price: 199,
    originalPrice: 249,
    rating: 4.8,
    reviews: 92,
    inStock: true,
    stockCount: 65,
    unit: "per 1kg pack",
    image: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80",
    description: "Naturally sweet and juicy hand-harvested Gala apples from mountain valley orchards. Clean, crisp bite packed with fiber and antioxidants.",
    origin: "Kinnaur Mountain Orchards",
    shelfLife: "14 Days",
    certifications: "GlobalGAP, 100% Natural"
  },
  {
    id: 3,
    name: "Hydroponic Baby Spinach",
    category: "fresh",
    categoryName: "Fresh Foods",
    badge: "Pesticide-Free",
    badgeType: "primary",
    price: 89,
    originalPrice: 120,
    rating: 4.9,
    reviews: 130,
    inStock: true,
    stockCount: 28,
    unit: "per 250g clamshell",
    image: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80",
    description: "Tender, triple-washed baby spinach grown in eco-hydroponic greenhouses. Ultra-fresh, iron-rich, and ready to eat raw or sautéed.",
    origin: "Union Hydro Greenhouses",
    shelfLife: "7 Days (Chilled)",
    certifications: "Zero Pesticide Residue"
  },
  {
    id: 4,
    name: "Heirloom Vine Tomatoes",
    category: "fresh",
    categoryName: "Fresh Foods",
    badge: "Seasonal",
    badgeType: "accent",
    price: 99,
    originalPrice: 140,
    rating: 4.7,
    reviews: 76,
    inStock: true,
    stockCount: 35,
    unit: "per 500g bunch",
    image: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80",
    description: "Rich, succulent heirloom tomatoes picked on the vine with unmistakable sun-warmed tomato aroma. Superb for salads, roasts, and gravies.",
    origin: "Organic Valley Collectives",
    shelfLife: "8 Days",
    certifications: "Organic India Certified"
  },

  // Snacks & Nuts
  {
    id: 5,
    name: "Roasted Mediterranean Almonds",
    category: "snacks",
    categoryName: "Snacks",
    badge: "Best Seller",
    badgeType: "bestseller",
    price: 499,
    originalPrice: 650,
    rating: 5.0,
    reviews: 312,
    inStock: true,
    stockCount: 50,
    unit: "per 250g pouch",
    image: "https://images.unsplash.com/photo-1508061252445-5350f3ab0a55?auto=format&fit=crop&w=600&q=80",
    description: "Slow-roasted with Aegean sea salt and extra virgin rosemary oil. Crisp, wholesome protein snack for active days.",
    origin: "Mediterranean Organic Groves",
    shelfLife: "12 Months",
    certifications: "Non-GMO, Gluten-Free"
  },
  {
    id: 6,
    name: "Organic Dried Turkish Figs",
    category: "snacks",
    categoryName: "Snacks",
    badge: "Sun-Dried",
    badgeType: "accent",
    price: 399,
    originalPrice: 499,
    rating: 4.8,
    reviews: 144,
    inStock: true,
    stockCount: 30,
    unit: "per 300g pack",
    image: "https://images.unsplash.com/photo-1546548970-71785318a17b?auto=format&fit=crop&w=600&q=80",
    description: "Sun-ripened soft dried figs with rich caramel notes and no added sulfur or preservatives. High in dietary fiber and potassium.",
    origin: "Izmir Mountain Estates",
    shelfLife: "18 Months",
    certifications: "100% Raw Organic"
  },
  {
    id: 7,
    name: "Quinoa & Sea Salt Crisps",
    category: "snacks",
    categoryName: "Snacks",
    badge: "Gluten-Free",
    badgeType: "new",
    price: 149,
    originalPrice: 199,
    rating: 4.6,
    reviews: 88,
    inStock: true,
    stockCount: 15,
    unit: "per 150g bag",
    image: "https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=600&q=80",
    description: "Air-popped organic Andean quinoa blended with chia seeds and Atlantic sea salt. 60% less fat than standard potato chips.",
    origin: "Artisan Crunch Kitchens",
    shelfLife: "9 Months",
    certifications: "Vegan, Certified Gluten-Free"
  },

  // Dairy Products
  {
    id: 8,
    name: "Pasture-Raised Whole Milk",
    category: "dairy",
    categoryName: "Dairy Products",
    badge: "Farm Fresh",
    badgeType: "primary",
    price: 78,
    originalPrice: 95,
    rating: 4.9,
    reviews: 245,
    inStock: true,
    stockCount: 70,
    unit: "per 1L bottle",
    image: "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80",
    description: "Non-homogenized, flash-pasteurized whole A2 milk from grass-fed family dairy farms. Naturally sweet, rich in omega-3 and vitamins.",
    origin: "Alpine Grasslands Cooperative",
    shelfLife: "6 Days (Chilled)",
    certifications: "FSSAI Grade A, Non-GMO"
  },
  {
    id: 9,
    name: "Aged Artisan Cheddar Wedge",
    category: "dairy",
    categoryName: "Dairy Products",
    badge: "Aged 18 Mo.",
    badgeType: "accent",
    price: 549,
    originalPrice: 699,
    rating: 5.0,
    reviews: 178,
    inStock: true,
    stockCount: 22,
    unit: "per 250g wedge",
    image: "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?auto=format&fit=crop&w=600&q=80",
    description: "Traditional clothbound cheddar aged in limestone caves for 18 months. Intense, nutty flavor profile with crystalline crunch.",
    origin: "Artisan Dairy Guild",
    shelfLife: "6 Months",
    certifications: "Artisan PDO Certified"
  },
  {
    id: 10,
    name: "Greek Strained Yogurt Tub",
    category: "dairy",
    categoryName: "Dairy Products",
    badge: "High Protein",
    badgeType: "primary",
    price: 199,
    originalPrice: 249,
    rating: 4.9,
    reviews: 160,
    inStock: true,
    stockCount: 40,
    unit: "per 400g tub",
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80",
    description: "Authentically triple-strained Greek yogurt with zero gelatin, thick velvet texture, and live active probiotic cultures.",
    origin: "Himalayan Foothills Dairy",
    shelfLife: "15 Days (Chilled)",
    certifications: "Live Probiotic Verified"
  },

  // Beverages
  {
    id: 11,
    name: "Cold-Pressed Valencia Orange",
    category: "beverages",
    categoryName: "Beverages",
    badge: "100% Raw",
    badgeType: "primary",
    price: 169,
    originalPrice: 219,
    rating: 4.8,
    reviews: 115,
    inStock: true,
    stockCount: 55,
    unit: "per 1L bottle",
    image: "https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&w=600&q=80",
    description: "100% pure squeezed Valencia oranges processed under cold hydraulic pressure. No water dilution, added sugar, or artificial shelf extenders.",
    origin: "Sun-Drenched Citrus Orchards",
    shelfLife: "10 Days (Refrigerated)",
    certifications: "Cold HPP Processed"
  },
  {
    id: 12,
    name: "Ceremonial Grade Matcha",
    category: "beverages",
    categoryName: "Beverages",
    badge: "Top Grade",
    badgeType: "accent",
    price: 1299,
    originalPrice: 1599,
    rating: 5.0,
    reviews: 84,
    inStock: true,
    stockCount: 18,
    unit: "per 80g tin",
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80",
    description: "First spring harvest tencha shade-grown in Uji, Japan, and granite-stone ground to an ultra-fine vibrant green powder. Umami-rich and energizing.",
    origin: "Uji, Kyoto, Japan",
    shelfLife: "18 Months",
    certifications: "JAS Organic, ceremonial grade"
  },
  {
    id: 13,
    name: "Sparkling Botanical Kombucha",
    category: "beverages",
    categoryName: "Beverages",
    badge: "Probiotic",
    badgeType: "new",
    price: 149,
    originalPrice: 189,
    rating: 4.7,
    reviews: 65,
    inStock: true,
    stockCount: 38,
    unit: "per 330ml bottle",
    image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
    description: "Naturally fermented raw kombucha infused with wild hibiscus blossoms and fresh pressed ginger. Crisp, bubbling gut health tonic.",
    origin: "Union Brew Collective",
    shelfLife: "60 Days (Chilled)",
    certifications: "USDA Organic, Vegan"
  },

  // Frozen Foods
  {
    id: 14,
    name: "Wild Alaskan Salmon Fillets",
    category: "frozen",
    categoryName: "Frozen Foods",
    badge: "Wild Caught",
    badgeType: "primary",
    price: 899,
    originalPrice: 1199,
    rating: 4.9,
    reviews: 198,
    inStock: true,
    stockCount: 26,
    unit: "per 500g pack",
    image: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80",
    description: "Flash-frozen within hours of harvest in icy Alaskan waters. Ruby-red flesh packed with healthy omega-3 fatty acids and clean sea flavor.",
    origin: "Bristol Bay, Alaska",
    shelfLife: "12 Months (Frozen)",
    certifications: "MSC Certified Sustainable"
  },
  {
    id: 15,
    name: "Organic Berry Medley",
    category: "frozen",
    categoryName: "Frozen Foods",
    badge: "Flash Frozen",
    badgeType: "accent",
    price: 349,
    originalPrice: 449,
    rating: 4.8,
    reviews: 142,
    inStock: true,
    stockCount: 45,
    unit: "per 500g bag",
    image: "https://images.unsplash.com/photo-1498557850523-fd3d118b962e?auto=format&fit=crop&w=600&q=80",
    description: "Individually quick frozen blueberries, raspberries, and blackberries. Retains 98% of fresh picked antioxidants, perfect for daily smoothies.",
    origin: "Pacific Northwest Farms",
    shelfLife: "18 Months (Frozen)",
    certifications: "USDA Organic"
  },
  {
    id: 16,
    name: "Artisan Wood-Fired Margherita",
    category: "frozen",
    categoryName: "Frozen Foods",
    badge: "Stone Baked",
    badgeType: "new",
    price: 399,
    originalPrice: 499,
    rating: 4.7,
    reviews: 89,
    inStock: true,
    stockCount: 20,
    unit: "per 420g pizza",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80",
    description: "Slow-risen Neapolitan dough topped with San Marzano tomatoes, fresh buffalo mozzarella, and fresh sweet basil, pre-baked in birch wood ovens.",
    origin: "Naples Heritage Recipe",
    shelfLife: "9 Months (Frozen)",
    certifications: "Traditional Italian Recipe"
  },

  // Bakery Products
  {
    id: 17,
    name: "Artisan Sourdough Country Loaf",
    category: "bakery",
    categoryName: "Bakery Products",
    badge: "Daily Hearth",
    badgeType: "bestseller",
    price: 189,
    originalPrice: 239,
    rating: 4.9,
    reviews: 210,
    inStock: true,
    stockCount: 32,
    unit: "per loaf (700g)",
    image: "https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=600&q=80",
    description: "Naturally fermented for 36 hours with our hundred-year-old sourdough mother. Caramelized blistered crust with a soft, open honeycomb crumb.",
    origin: "Union Hearth Bakery",
    shelfLife: "5 Days",
    certifications: "Wild Ferment, Zero Additives"
  },
  {
    id: 18,
    name: "Multi-Seed Ancient Grain Bread",
    category: "bakery",
    categoryName: "Bakery Products",
    badge: "High Fiber",
    badgeType: "primary",
    price: 199,
    originalPrice: 249,
    rating: 4.8,
    reviews: 95,
    inStock: true,
    stockCount: 24,
    unit: "per loaf (650g)",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",
    description: "Loaded with toasted pumpkin, flax, sunflower, and sesame seeds. High protein and low glycemic index for lasting energy.",
    origin: "Union Hearth Bakery",
    shelfLife: "6 Days",
    certifications: "100% Whole Grain Council"
  },
  {
    id: 19,
    name: "Golden Brioche Burger Buns",
    category: "bakery",
    categoryName: "Bakery Products",
    badge: "Buttery Soft",
    badgeType: "accent",
    price: 149,
    originalPrice: 189,
    rating: 4.8,
    reviews: 112,
    inStock: true,
    stockCount: 40,
    unit: "4-pack",
    image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80",
    description: "Enriched with real grass-fed butter and farm fresh eggs. Pillowy soft, glossy glaze, ideal for gourmet burgers and sandwiches.",
    origin: "Union Pastry Kitchen",
    shelfLife: "5 Days",
    certifications: "Free-Range Egg Certified"
  },

  // Grocery Essentials
  {
    id: 20,
    name: "Extra Virgin Cold-Pressed Olive Oil",
    category: "grocery",
    categoryName: "Grocery Essentials",
    badge: "Single Estate",
    badgeType: "primary",
    price: 899,
    originalPrice: 1199,
    rating: 5.0,
    reviews: 320,
    inStock: true,
    stockCount: 60,
    unit: "per 750ml glass bottle",
    image: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80",
    description: "First cold press of hand-harvested Koroneiki olives within four hours of picking. Acidity < 0.2%, boasting pepper finish and polyphenols.",
    origin: "Single Estate Organic Farm",
    shelfLife: "24 Months",
    certifications: "PDO Certified, Extra Virgin"
  },
  {
    id: 21,
    name: "Stoneground Whole Wheat Flour",
    category: "grocery",
    categoryName: "Grocery Essentials",
    badge: "Stone Milled",
    badgeType: "accent",
    price: 349,
    originalPrice: 420,
    rating: 4.9,
    reviews: 140,
    inStock: true,
    stockCount: 50,
    unit: "per 5kg sack",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80",
    description: "Unbleached and unbromated hard red winter wheat stoneground cold to preserve natural vitamins, germ oils, and natural baking aromas.",
    origin: "Union Certified Mills",
    shelfLife: "12 Months",
    certifications: "Jaivik Bharat, USDA Organic"
  },
  {
    id: 22,
    name: "Raw Mountain Wildflower Honey",
    category: "grocery",
    categoryName: "Grocery Essentials",
    badge: "Unheated & Pure",
    badgeType: "bestseller",
    price: 449,
    originalPrice: 560,
    rating: 5.0,
    reviews: 285,
    inStock: true,
    stockCount: 34,
    unit: "per 500g jar",
    image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80",
    description: "Completely raw and unpasteurized wildflower honey harvested from pristine highland apiaries. Packed with live enzymes and natural pollen.",
    origin: "Highland Forest Apiaries",
    shelfLife: "Indefinite (Raw Honey)",
    certifications: "100% Pure Raw Honey"
  },
  {
    id: 23,
    name: "Pure Himalayan Coarse Pink Salt",
    category: "grocery",
    categoryName: "Grocery Essentials",
    badge: "84 Minerals",
    badgeType: "new",
    price: 129,
    originalPrice: 169,
    rating: 4.8,
    reviews: 78,
    inStock: true,
    stockCount: 45,
    unit: "per 1kg pouch",
    image: "https://images.unsplash.com/photo-1518110925495-5fe2fda9543e?auto=format&fit=crop&w=600&q=80",
    description: "Ancient crystal salt hand-mined from pristine subterranean Himalayan deposits. Contains 84 trace minerals, untreated with anti-caking agents.",
    origin: "Himalayan Salt Range",
    shelfLife: "Indefinite",
    certifications: "100% Natural Crystal"
  },
  {
    id: 24,
    name: "Aromatic Tellicherry Peppercorns",
    category: "grocery",
    categoryName: "Grocery Essentials",
    badge: "Grade A",
    badgeType: "accent",
    price: 249,
    originalPrice: 320,
    rating: 4.9,
    reviews: 135,
    inStock: true,
    stockCount: 30,
    unit: "per 200g tin",
    image: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80",
    description: "Extra-bold sun-dried black peppercorns from Malabar coast. Distinctive cedar aroma with sharp, clean heat for seasoning.",
    origin: "Kerala Malabar Coast",
    shelfLife: "36 Months",
    certifications: "Ethically Fair Trade Sourced"
  }
];

// --------------------------------------------------------------------------
// 2. Gourmet Recipes Dataset
// --------------------------------------------------------------------------
const unionRecipes = [
  {
    id: 1,
    title: "Artisan Sourdough Avocado Toast",
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80",
    prepTime: "15 Mins",
    difficulty: "Easy",
    servings: "2 Servings",
    calories: "320 kcal",
    description: "Crisp toasted slices of our 36-hour sourdough loaded with mashed California avocado, poached eggs, and cold-pressed extra virgin olive oil.",
    ingredients: [
      "2 slices Union Foods Artisan Sourdough Country Loaf",
      "2 ripe Union Foods Hass Avocados",
      "2 farm fresh pasture-raised eggs",
      "1 tbsp Union Foods Extra Virgin Olive Oil",
      "A pinch of Himalayan Pink Salt and crushed Tellicherry Black Pepper",
      "Chili flakes and fresh microgreens for garnish"
    ],
    instructions: [
      "Thickly slice the sourdough loaf and toast until deep golden brown and fragrant.",
      "In a small bowl, coarsely mash avocados with olive oil, sea salt, and a squeeze of fresh lemon.",
      "Bring a small pot of water to a gentle simmer with a drop of vinegar, then poach eggs for 3 minutes until yolks remain soft.",
      "Generously spread avocado over toast, crown with poached egg, season with fresh pepper, and drizzle olive oil."
    ]
  },
  {
    id: 2,
    title: "Mediterranean Greek Salad Bowl",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80",
    prepTime: "12 Mins",
    difficulty: "Easy",
    servings: "4 Servings",
    calories: "280 kcal",
    description: "Crisp heirloom vine tomatoes, cucumbers, Kalamata olives, and aged artisan cheese tossed in oregano cold-pressed olive oil vinaigrette.",
    ingredients: [
      "4 Union Foods Heirloom Vine Tomatoes, cut into wedges",
      "1 crisp English cucumber, sliced into thick rounds",
      "150g Union Foods Aged Artisan Cheese or Feta block",
      "1/2 cup Kalamata olives in brine",
      "3 tbsp Union Foods Extra Virgin Olive Oil",
      "1 tbsp red wine vinegar and dried wild mountain oregano"
    ],
    instructions: [
      "Combine cut tomatoes and cucumbers in a wide shallow salad bowl.",
      "Scatter Kalamata olives and thinly sliced red onions across the vegetables.",
      "Whisk olive oil, red wine vinegar, oregano, and pink salt together; pour over salad.",
      "Place the cheese block right in the center, dust with oregano, and serve immediately."
    ]
  },
  {
    id: 3,
    title: "Pan-Seared Alaskan Salmon with Garlic Spinach",
    image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=600&q=80",
    prepTime: "20 Mins",
    difficulty: "Medium",
    servings: "2 Servings",
    calories: "460 kcal",
    description: "Crispy skin wild salmon fillets seared in cultured butter, paired with quick-sautéed baby spinach and fresh lemon juice.",
    ingredients: [
      "2 Union Foods Wild Alaskan Salmon Fillets (thawed)",
      "300g Union Foods Hydroponic Baby Spinach",
      "2 cloves garlic, finely minced",
      "2 tbsp Union Foods Extra Virgin Olive Oil",
      "1 tbsp butter and 1 fresh lemon",
      "Sea salt and freshly ground pepper"
    ],
    instructions: [
      "Pat salmon fillets dry with paper towels; score skin lightly and season with sea salt.",
      "Heat olive oil in a heavy stainless steel skillet over medium-high heat until glistening.",
      "Place salmon skin-side down; press lightly with spatula for 4 minutes until skin is ultra-crisp.",
      "Flip salmon for 2 more minutes; remove to rest.",
      "In the same pan, flash sauté minced garlic and baby spinach for 90 seconds until wilted. Serve alongside salmon."
    ]
  },
  {
    id: 4,
    title: "Berry Antioxidant Superfood Smoothie",
    image: "https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=600&q=80",
    prepTime: "5 Mins",
    difficulty: "Easy",
    servings: "2 Glasses",
    calories: "210 kcal",
    description: "A velvety, power-packed blend of flash-frozen berries, strained Greek yogurt, raw wildflower honey, and cold-pressed orange juice.",
    ingredients: [
      "1.5 cups Union Foods Organic Berry Medley (frozen)",
      "1 cup Union Foods Greek Strained Yogurt",
      "1/2 cup Union Foods Cold-Pressed Orange Juice",
      "1 tbsp Union Foods Raw Mountain Wildflower Honey",
      "1 tbsp chia seeds"
    ],
    instructions: [
      "Add frozen berry medley, Greek yogurt, orange juice, and honey into a high-speed blender container.",
      "Blend on low for 20 seconds, then increase to high speed for 45 seconds until thick and silky.",
      "Pour into chilled glasses, sprinkle chia seeds on top, and enjoy immediate fresh vitality."
    ]
  }
];

// --------------------------------------------------------------------------
// 3. Product Card HTML Generator (Indian Rupee ₹)
// --------------------------------------------------------------------------
function createProductCardHTML(product) {
  const discountPercent = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
  const isInWish = window.unionWishlist ? window.unionWishlist.isInWishlist(product.id) : false;

  return `
    <article class="product-card reveal-on-scroll" data-id="${product.id}" data-category="${product.category}">
      <div class="product-badge-stack">
        ${product.badge ? `<span class="badge badge-${product.badgeType || 'primary'}">${product.badge}</span>` : ''}
        ${discountPercent > 0 ? `<span class="badge badge-sale">-${discountPercent}%</span>` : ''}
      </div>

      <div class="product-actions-stack">
        <button type="button" class="btn-card-action btn-wishlist-toggle ${isInWish ? 'active-wishlist' : ''}" 
                data-id="${product.id}" 
                aria-label="Add ${product.name} to wishlist"
                title="Add to Wishlist">
          <i class="${isInWish ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
        </button>
        <button type="button" class="btn-card-action btn-quickview-open" 
                data-id="${product.id}" 
                aria-label="Quick view ${product.name}"
                title="Quick View">
          <i class="fa-regular fa-eye"></i>
        </button>
      </div>

      <div class="product-img-box">
        <img src="${product.image}" alt="${product.name}" loading="lazy" />
      </div>

      <div class="product-body">
        <div class="product-meta-row">
          <span class="product-category-name">${product.categoryName}</span>
          <div class="product-rating">
            <i class="fa-solid fa-star"></i>
            <span>${product.rating.toFixed(1)} (${product.reviews})</span>
          </div>
        </div>

        <h3 class="product-title" title="${product.name}">${product.name}</h3>
        <p class="product-desc">${product.description}</p>

        <div class="product-footer-row">
          <div class="price-box">
            <span class="current-price">${formatPrice(product.price)}</span>
            ${product.originalPrice ? `<span class="old-price">${formatPrice(product.originalPrice)}</span>` : ''}
          </div>
          <span class="product-stock-status ${product.stockCount < 20 ? 'low-stock' : ''}">
            <i class="fa-solid fa-circle-check"></i> ${product.stockCount < 20 ? 'Low Stock (' + product.stockCount + ')' : 'In Stock'}
          </span>
        </div>

        <button type="button" class="btn btn-primary btn-add-cart btn-ripple" data-id="${product.id}">
          <i class="fa-solid fa-cart-shopping"></i>
          <span>Add to Basket</span>
        </button>
      </div>
    </article>
  `;
}

// --------------------------------------------------------------------------
// 4. Render Products Grid with Category Filter & Sorting
// --------------------------------------------------------------------------
function renderProducts(filterCategory = 'all', sortBy = 'default', searchQuery = '', containerId = 'productsGrid') {
  const container = document.getElementById(containerId);
  if (!container) return;

  // Filter
  let filtered = unionProducts.filter(item => {
    const matchesCategory = (filterCategory === 'all' || item.category === filterCategory);
    const matchesSearch = (!searchQuery || item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                          item.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                          item.categoryName.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // Sort
  if (sortBy === 'price-low') {
    filtered.sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price-high') {
    filtered.sort((a, b) => b.price - a.price);
  } else if (sortBy === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  } else if (sortBy === 'name') {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  }

  // Empty state handling
  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 3rem 1rem;">
        <i class="fa-solid fa-magnifying-glass" style="font-size: 2.5rem; color: var(--text-light); margin-bottom: 1rem;"></i>
        <h4 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem;">No products match your criteria</h4>
        <p style="color: var(--text-muted); font-size: 0.9rem;">Try selecting a different category or clearing search terms.</p>
        <button type="button" class="btn btn-primary btn-sm" id="btnResetFilters" style="margin-top: 1rem;">View All Products</button>
      </div>
    `;
    const resetBtn = document.getElementById('btnResetFilters');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        const searchInput = document.getElementById('catalogSearchInput');
        if (searchInput) searchInput.value = '';
        const allPill = document.querySelector('.filter-pill[data-filter="all"]');
        if (allPill) allPill.click();
        else renderProducts('all', 'default', '', containerId);
      });
    }
    return;
  }

  // Render cards
  container.innerHTML = filtered.map(item => createProductCardHTML(item)).join('');

  // Attach card event listeners via delegation
  attachProductCardEvents(container);

  // Trigger scroll reveal
  if (window.unionScrollReveal) {
    window.unionScrollReveal();
  }
}

// --------------------------------------------------------------------------
// 5. Attach Product Card Events (Add to Cart, Wishlist, QuickView)
// --------------------------------------------------------------------------
function attachProductCardEvents(container) {
  // Add to cart buttons
  container.querySelectorAll('.btn-add-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = parseInt(btn.dataset.id);
      if (window.unionCart) {
        window.unionCart.addToCart(id, 1);
      }
    });
  });

  // Wishlist toggle buttons
  container.querySelectorAll('.btn-wishlist-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = parseInt(btn.dataset.id);
      if (window.unionWishlist) {
        window.unionWishlist.toggleWishlist(id, btn);
      }
    });
  });

  // Quick view open buttons
  container.querySelectorAll('.btn-quickview-open').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = parseInt(btn.dataset.id);
      openQuickView(id);
    });
  });
}

// --------------------------------------------------------------------------
// 6. Quick View Modal Logic (Indian Rupee ₹)
// --------------------------------------------------------------------------
function openQuickView(productId) {
  const product = unionProducts.find(p => p.id === productId);
  if (!product) return;

  const modal = document.getElementById('quickViewModal');
  const backdrop = document.getElementById('modalBackdrop');
  if (!modal || !backdrop) return;

  // Track recently viewed
  if (window.unionTracker) {
    window.unionTracker.addRecentView(product.id);
  }

  const discountPercent = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  modal.innerHTML = `
    <button type="button" class="btn-modal-close" id="btnQuickViewClose" aria-label="Close modal">
      <i class="fa-solid fa-xmark"></i>
    </button>
    <div class="quickview-grid">
      <div class="quickview-img-box">
        <img src="${product.image}" alt="${product.name}" id="qvMainImg" />
      </div>
      <div class="quickview-info">
        <span class="product-category-name">${product.categoryName}</span>
        <h2 class="quickview-title">${product.name}</h2>
        
        <div class="quickview-price-row">
          <span class="current-price" style="font-size: 1.6rem; color: var(--primary);">${formatPrice(product.price)}</span>
          ${product.originalPrice ? `<span class="old-price" style="font-size: 1.1rem;">${formatPrice(product.originalPrice)}</span>` : ''}
          ${discountPercent > 0 ? `<span class="badge badge-sale">Save ${discountPercent}%</span>` : ''}
        </div>

        <p class="product-desc" style="display: block; margin-bottom: 1rem;">${product.description}</p>

        <div class="quickview-specs">
          <div class="spec-row">
            <span class="spec-label">Packaging / Quantity:</span>
            <span class="spec-value">${product.unit}</span>
          </div>
          <div class="spec-row">
            <span class="spec-label">Farm Origin:</span>
            <span class="spec-value">${product.origin}</span>
          </div>
          <div class="spec-row">
            <span class="spec-label">Shelf Life:</span>
            <span class="spec-value">${product.shelfLife}</span>
          </div>
          <div class="spec-row">
            <span class="spec-label">Certifications:</span>
            <span class="spec-value">${product.certifications}</span>
          </div>
        </div>

        <!-- Quantity & Cart Actions -->
        <div style="display: flex; align-items: center; gap: 1rem; margin-top: auto; flex-wrap: wrap;">
          <div class="cart-qty-controls" style="border: 2px solid var(--border-color); border-radius: var(--radius-md);">
            <button type="button" class="btn-qty" id="qvQtyMinus"><i class="fa-solid fa-minus"></i></button>
            <span class="qty-display" id="qvQtyDisplay">1</span>
            <button type="button" class="btn-qty" id="qvQtyPlus"><i class="fa-solid fa-plus"></i></button>
          </div>
          <button type="button" class="btn btn-primary btn-ripple" id="qvAddToCartBtn" style="flex-grow: 1; min-width: 150px;">
            <i class="fa-solid fa-cart-shopping"></i>
            <span>Add to Basket</span>
          </button>
          <button type="button" class="btn-card-action" id="qvWishlistBtn" style="width: 44px; height: 44px;" title="Add to Wishlist">
            <i class="fa-regular fa-heart"></i>
          </button>
        </div>
      </div>
    </div>
  `;

  // Attach internal modal events
  let currentQty = 1;
  const qtyMinus = modal.querySelector('#qvQtyMinus');
  const qtyPlus = modal.querySelector('#qvQtyPlus');
  const qtyDisplay = modal.querySelector('#qvQtyDisplay');
  const addCartBtn = modal.querySelector('#qvAddToCartBtn');
  const wishBtn = modal.querySelector('#qvWishlistBtn');
  const closeBtn = modal.querySelector('#btnQuickViewClose');

  if (qtyMinus && qtyPlus && qtyDisplay) {
    qtyMinus.addEventListener('click', () => {
      if (currentQty > 1) {
        currentQty--;
        qtyDisplay.textContent = currentQty;
      }
    });
    qtyPlus.addEventListener('click', () => {
      if (currentQty < product.stockCount) {
        currentQty++;
        qtyDisplay.textContent = currentQty;
      } else {
        if (window.unionToast) window.unionToast('Stock Limit', `Maximum available stock is ${product.stockCount}`, 'warning');
      }
    });
  }

  if (addCartBtn) {
    addCartBtn.addEventListener('click', () => {
      if (window.unionCart) {
        window.unionCart.addToCart(product.id, currentQty);
        closeModal();
      }
    });
  }

  if (wishBtn) {
    const isWished = window.unionWishlist ? window.unionWishlist.isInWishlist(product.id) : false;
    if (isWished) {
      wishBtn.classList.add('active-wishlist');
      wishBtn.innerHTML = '<i class="fa-solid fa-heart"></i>';
    }
    wishBtn.addEventListener('click', () => {
      if (window.unionWishlist) {
        window.unionWishlist.toggleWishlist(product.id, wishBtn);
      }
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', closeModal);
  }

  // Open modal
  modal.classList.add('active');
  backdrop.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const activeModals = document.querySelectorAll('.modal-window.active');
  const backdrop = document.getElementById('modalBackdrop');
  activeModals.forEach(m => m.classList.remove('active'));
  if (backdrop) backdrop.classList.remove('active');
  document.body.style.overflow = '';
}

// --------------------------------------------------------------------------
// 7. Render Recipes Grid & Recipe Modal Logic
// --------------------------------------------------------------------------
function renderRecipes(containerId = 'recipesGrid') {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = unionRecipes.map(recipe => `
    <article class="recipe-card reveal-on-scroll">
      <div class="recipe-img-box">
        <img src="${recipe.image}" alt="${recipe.title}" loading="lazy" />
        <span class="recipe-time-tag">
          <i class="fa-regular fa-clock"></i> ${recipe.prepTime}
        </span>
      </div>
      <div class="recipe-body">
        <div class="recipe-meta-row">
          <span class="badge badge-accent">${recipe.difficulty}</span>
          <span><i class="fa-solid fa-fire"></i> ${recipe.calories}</span>
          <span><i class="fa-solid fa-users"></i> ${recipe.servings}</span>
        </div>
        <h3 class="recipe-title">${recipe.title}</h3>
        <p class="recipe-desc">${recipe.description}</p>
        <div class="recipe-footer">
          <button type="button" class="btn btn-outline btn-sm btn-view-recipe" data-id="${recipe.id}" style="width: 100%;">
            <span>View Recipe & Method</span>
            <i class="fa-solid fa-arrow-right"></i>
          </button>
        </div>
      </div>
    </article>
  `).join('');

  // Attach recipe modal event
  container.querySelectorAll('.btn-view-recipe').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      openRecipeModal(id);
    });
  });
}

function openRecipeModal(recipeId) {
  const recipe = unionRecipes.find(r => r.id === recipeId);
  if (!recipe) return;

  const modal = document.getElementById('recipeModal');
  const backdrop = document.getElementById('modalBackdrop');
  if (!modal || !backdrop) return;

  modal.innerHTML = `
    <button type="button" class="btn-modal-close" id="btnRecipeClose" aria-label="Close recipe modal">
      <i class="fa-solid fa-xmark"></i>
    </button>
    <div style="padding: 2.5rem;">
      <div style="display: flex; gap: 2rem; align-items: flex-start; margin-bottom: 2rem; flex-wrap: wrap;">
        <div style="width: 100%; max-width: 320px; height: 220px; border-radius: var(--radius-md); overflow: hidden; flex-shrink: 0;">
          <img src="${recipe.image}" alt="${recipe.title}" style="width: 100%; height: 100%; object-fit: cover;" />
        </div>
        <div style="flex-grow: 1;">
          <div style="display: flex; gap: 0.5rem; margin-bottom: 0.5rem;">
            <span class="badge badge-accent">${recipe.difficulty}</span>
            <span class="badge badge-primary"><i class="fa-regular fa-clock"></i> ${recipe.prepTime}</span>
          </div>
          <h2 style="font-size: 1.8rem; font-weight: 800; color: var(--text-main); margin-bottom: 0.5rem;">${recipe.title}</h2>
          <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.5;">${recipe.description}</p>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1.25fr; gap: 2.5rem;">
        <div>
          <h4 style="font-size: 1.15rem; font-weight: 700; color: var(--text-main); margin-bottom: 1rem; border-bottom: 2px solid var(--primary); padding-bottom: 0.35rem;">
            Ingredients Checklist
          </h4>
          <ul style="display: flex; flex-direction: column; gap: 0.65rem;">
            ${recipe.ingredients.map(ing => `
              <li style="display: flex; align-items: flex-start; gap: 0.5rem; font-size: 0.9rem; color: var(--text-main);">
                <i class="fa-solid fa-check" style="color: var(--primary); margin-top: 4px;"></i>
                <span>${ing}</span>
              </li>
            `).join('')}
          </ul>
        </div>

        <div>
          <h4 style="font-size: 1.15rem; font-weight: 700; color: var(--text-main); margin-bottom: 1rem; border-bottom: 2px solid var(--primary); padding-bottom: 0.35rem;">
            Step-by-Step Method
          </h4>
          <ol style="display: flex; flex-direction: column; gap: 0.85rem; counter-reset: recipe-counter;">
            ${recipe.instructions.map((step, idx) => `
              <li style="display: flex; gap: 0.75rem; font-size: 0.9rem; color: var(--text-muted); line-height: 1.5;">
                <span style="font-weight: 800; color: var(--primary); flex-shrink: 0; background: var(--primary-light); width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.75rem;">
                  ${idx + 1}
                </span>
                <span>${step}</span>
              </li>
            `).join('')}
          </ol>
        </div>
      </div>
    </div>
  `;

  modal.querySelector('#btnRecipeClose').addEventListener('click', closeModal);
  modal.classList.add('active');
  backdrop.classList.add('active');
  document.body.style.overflow = 'hidden';
}

// Export to window
window.CURRENCY_SYMBOL = CURRENCY_SYMBOL;
window.formatPrice = formatPrice;
window.formatPriceDecimal = formatPriceDecimal;
window.unionProducts = unionProducts;
window.unionRecipes = unionRecipes;
window.renderProducts = renderProducts;
window.renderRecipes = renderRecipes;
window.openQuickView = openQuickView;
window.openRecipeModal = openRecipeModal;
window.closeModal = closeModal;
