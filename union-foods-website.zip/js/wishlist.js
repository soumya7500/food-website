/**
 * Union Foods - Wishlist Manager (wishlist.js)
 * Pure Vanilla JavaScript ES6+
 */

class WishlistManager {
  constructor() {
    this.storageKey = 'union_foods_wishlist';
    this.wishlist = this.loadWishlist();
    this.init();
  }

  loadWishlist() {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error('Error loading wishlist', e);
      return [];
    }
  }

  saveWishlist() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.wishlist));
    } catch (e) {
      console.error('Error saving wishlist', e);
    }
    this.updateBadges();
    this.renderWishlistDrawer();
  }

  init() {
    this.updateBadges();
    this.attachDrawerTriggers();
  }

  isInWishlist(productId) {
    return this.wishlist.some(item => item.id === productId);
  }

  toggleWishlist(productId, buttonElement = null) {
    const product = window.unionProducts ? window.unionProducts.find(p => p.id === productId) : null;
    if (!product) return;

    const exists = this.isInWishlist(productId);

    if (exists) {
      this.wishlist = this.wishlist.filter(item => item.id !== productId);
      if (buttonElement) {
        buttonElement.classList.remove('active-wishlist');
        buttonElement.innerHTML = '<i class="fa-regular fa-heart"></i>';
      }
      if (window.unionToast) {
        window.unionToast('Removed from Wishlist', `${product.name} removed from your saved items.`, 'info');
      }
    } else {
      this.wishlist.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        categoryName: product.categoryName,
        stockCount: product.stockCount
      });
      if (buttonElement) {
        buttonElement.classList.add('active-wishlist');
        buttonElement.innerHTML = '<i class="fa-solid fa-heart"></i>';
      }
      if (window.unionToast) {
        window.unionToast('Added to Wishlist', `${product.name} saved to your favorites.`, 'success');
      }
    }

    this.saveWishlist();

    // Sync other buttons on page for this product
    document.querySelectorAll(`.btn-wishlist-toggle[data-id="${productId}"]`).forEach(btn => {
      if (btn !== buttonElement) {
        if (!exists) {
          btn.classList.add('active-wishlist');
          btn.innerHTML = '<i class="fa-solid fa-heart"></i>';
        } else {
          btn.classList.remove('active-wishlist');
          btn.innerHTML = '<i class="fa-regular fa-heart"></i>';
        }
      }
    });
  }

  moveToCart(productId) {
    const item = this.wishlist.find(i => i.id === productId);
    if (!item) return;

    if (window.unionCart) {
      window.unionCart.addToCart(productId, 1);
      this.toggleWishlist(productId);
    }
  }

  updateBadges() {
    const count = this.wishlist.length;
    document.querySelectorAll('.wishlist-badge-count').forEach(el => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  renderWishlistDrawer() {
    const container = document.getElementById('wishlistDrawerBody');
    if (!container) return;

    if (this.wishlist.length === 0) {
      container.innerHTML = `
        <div class="drawer-empty-state">
          <div class="empty-icon"><i class="fa-regular fa-heart"></i></div>
          <h4 class="empty-title">Your Wishlist is Empty</h4>
          <p class="empty-desc">Save your favorite organic goods and seasonal picks to access them anytime.</p>
          <button type="button" class="btn btn-primary btn-sm btn-close-wishlist-explore">
            <span>Explore Farm Catalog</span>
            <i class="fa-solid fa-arrow-right"></i>
          </button>
        </div>
      `;

      const exploreBtn = container.querySelector('.btn-close-wishlist-explore');
      if (exploreBtn) {
        exploreBtn.addEventListener('click', () => {
          this.closeWishlistDrawer();
          const target = document.getElementById('products');
          if (target) target.scrollIntoView({ behavior: 'smooth' });
        });
      }
      return;
    }

    container.innerHTML = this.wishlist.map(item => `
      <div class="cart-drawer-item" data-id="${item.id}">
        <img src="${item.image}" alt="${item.name}" class="cart-item-img" />
        <div class="cart-item-info">
          <span style="font-size: 0.72rem; text-transform: uppercase; font-weight: 700; color: var(--primary);">${item.categoryName || 'Organic'}</span>
          <h4 class="cart-item-name">${item.name}</h4>
          <div class="cart-item-price">₹${Math.round(item.price).toLocaleString('en-IN')}</div>
          <button type="button" class="btn btn-primary btn-sm btn-wishlist-movetocart" data-id="${item.id}" style="margin-top: 0.4rem;">
            <i class="fa-solid fa-cart-plus"></i> Move to Basket
          </button>
        </div>
        <button type="button" class="btn-remove-item btn-wishlist-remove" data-id="${item.id}" title="Remove from wishlist" aria-label="Remove from wishlist">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
    `).join('');

    container.querySelectorAll('.btn-wishlist-movetocart').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.id);
        this.moveToCart(id);
      });
    });

    container.querySelectorAll('.btn-wishlist-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.id);
        this.toggleWishlist(id);
      });
    });
  }

  attachDrawerTriggers() {
    const triggers = document.querySelectorAll('.btn-wishlist-drawer-toggle');
    const drawer = document.getElementById('wishlistDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    const closeBtn = document.getElementById('btnWishlistDrawerClose');

    triggers.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openWishlistDrawer();
      });
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeWishlistDrawer());
    }
  }

  openWishlistDrawer() {
    const drawer = document.getElementById('wishlistDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    if (drawer && backdrop) {
      this.renderWishlistDrawer();
      drawer.classList.add('active');
      backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  closeWishlistDrawer() {
    const drawer = document.getElementById('wishlistDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    if (drawer && backdrop) {
      drawer.classList.remove('active');
      backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
  }
}

// Global instance
window.unionWishlist = new WishlistManager();
