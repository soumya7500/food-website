# Union Foods – Fully Responsive & Dynamic Commercial Website

> A premier, commercial-grade food brand website built with pure **HTML5**, **CSS3**, and modular **Vanilla JavaScript (ES6+)**. Fully responsive across all devices, featuring 50+ dynamic interactive features, dark/light theme mode, shopping cart with cold-chain checkout, wishlist, live shipment tracking, recipes, and robust form validation.

---

## 🌟 Executive Project Overview

**Union Foods** is designed to represent an industry-leading organic food manufacturing and cold-chain distribution enterprise. The website strictly adheres to modern frontend best practices, maintaining a clean organic aesthetic, accessible landmark architecture, fluid responsive grids, smooth micro-interactions, and instant client-side state persistence without reliance on third-party frameworks.

- **Frontend Tech**: Pure HTML5 (Semantic), CSS3 (Custom Variables, Flexbox, Grid), Vanilla JavaScript (Modular ES6+).
- **Typography & Icons**: Google Fonts (*Plus Jakarta Sans*), Font Awesome 6 Icons, Custom SVGs.
- **Design Aesthetic**: Emerald green palette (`#15803d`), harvest gold accents (`#f59e0b`), slate typography, and full dark-mode adaptation.

---

## 📁 Project Directory Structure

```text
Union-Foods/
│
├── index.html                   # Flagship portal showcasing all 12 commercial sections
│
├── pages/
│   ├── about.html               # Heritage, mission, agronomist leadership & certifications
│   ├── products.html            # Full store catalog with sidebar price slider & category filters
│   ├── recipes.html             # Gourmet culinary recipes with prep times, tags & method modal
│   ├── contact.html             # Direct departments, inquiries form, and interactive FAQs
│   └── checkout.html            # Multi-step cold-chain checkout & live sensor tracking
│
├── css/
│   ├── style.css                # Master stylesheet with CSS variables (Light & Dark theme)
│   ├── responsive.css           # Media queries for 1440px+, 1024px, 768px, 320px breakpoints
│   └── animations.css           # Keyframe animations, skeleton shimmers, floating badges, ripples
│
├── js/
│   ├── products.js              # Comprehensive dataset (24+ items, 7 categories, recipes & modals)
│   ├── cart.js                  # Shopping cart drawer, financial calculations, coupons & checkout
│   ├── wishlist.js              # Favorites system, heart animations, and 'Move to Basket' action
│   ├── validation.js            # Form validation engine, regex checks, and floating toast system
│   └── main.js                  # Theme switcher, countdown timer, slider, counters, search & auth
│
├── assets/
│   ├── images/                  # High-resolution food photography & assets
│   └── icons/
│       ├── logo.svg             # Vector brand emblem
│       └── favicon.svg          # Crisp browser favicon
│
├── README.md                    # Complete technical documentation & setup instructions
└── union-foods-website.zip      # Complete compressed archive for immediate evaluation
```

---

## 🚀 50+ Interactive Features Breakdown

### 🧭 Navigation & Core UI
1. **Sticky Navigation Bar**: Dynamic elevation shadow and backdrop blur upon scrolling.
2. **Responsive Hamburger Drawer**: Slide-in mobile menu with smooth overlay backdrop.
3. **Smooth Scroll Anchors**: Fluid navigation scrolling with sticky header offset correction.
4. **Dropdown Navigation Menus**: Nested menus for categories with quick links.
5. **Scroll-Spy Active Link Highlighting**: Automatically highlights current section in view.
6. **Back-to-Top Floating Button**: Appears after 350px scroll with smooth top scrolling.
7. **Mobile Drawer Click-Outside Dismiss**: Auto-closes on outside tap or Escape key press.
8. **Dark and Light Mode Toggle**: Smooth theme transition with `localStorage` persistence.
9. **Page Preloader**: Animated spinner fading seamlessly upon DOM content readiness.
10. **Button Ripple Micro-Interaction**: Material-style click ripples on primary actions.

### 🍎 Product Catalog & Discovery
11. **Comprehensive Product Dataset**: 24 realistic food items across all 7 required categories.
12. **Dynamic Category Filtering**: Filter pills (Fresh, Snacks, Dairy, Beverages, Frozen, Bakery, Grocery).
13. **Sorting Engine**: Sort by Featured, Price (Low-High), Price (High-Low), Rating, Alphabetical.
14. **Live Product Search**: Instant filtering by product name, category, or description.
15. **Clear Search Action (X)**: One-click reset for quick keyword clearing.
16. **Product Quick View Modal**: High-res image, nutritional specs, origin, shelf-life, and unit info.
17. **Dynamic Discount Badge Calculation**: Automatic percentage calculation based on original vs sale price.
18. **Stock Availability Indicator**: Dynamic "In Stock" vs "Low Stock" indicators.
19. **Interactive Category Cards**: Image category cards on homepage that auto-filter the product grid.
20. **Recently Viewed Shelf**: Dynamically tracks clicked products and persists in `localStorage`.

### 🛒 Shopping Basket & Wishlist
21. **Add to Cart**: Instant addition with stock limit verification.
22. **Shopping Cart Sidebar Drawer**: Slide-out drawer with backdrop.
23. **Quantity Stepper (+ / -)**: Instant increment/decrement with minimum of 1 and maximum stock ceiling.
24. **Remove Item from Basket**: Individual item deletion with toast confirmation.
25. **Clear Basket with Confirmation**: Custom modal dialog preventing accidental clears.
26. **Free Shipping Progress Meter**: Visual progress bar indicating dollars remaining for free delivery.
27. **Cart Item Counter Badge**: Real-time counter badge synced in the header.
28. **Cart Financial Engine**: Subtotal, estimated 8% tax, and cold-chain shipping calculation.
29. **Add to Wishlist**: Toggle favorites with heart beat animation.
30. **Wishlist Counter Badge**: Dedicated counter badge in navbar.
31. **Wishlist Drawer**: View saved favorites.
32. **Move to Basket**: One-click transfer from wishlist directly into active shopping cart.

### 💳 Checkout & Order Tracking
33. **Coupon Code Engine**: Supports `UNION25` (25% off), `FREESHIP` ($0 delivery), and `WELCOME10`.
34. **Interactive Coupon Voucher Card**: One-click "Copy Code" button with clipboard integration.
35. **Multi-Step Checkout**: Customer details, shipping address, and payment method selection.
36. **Order Submission Simulator**: Form processing animation with order number generation (`UF-XXXXX`).
37. **Order Confirmation Screen**: Order review with delivery dates and direct tracking button.
38. **Live Shipment Tracking**: Standalone tracker lookup by Order ID.
39. **4-Step Visual Progress Stepper**: Order Placed &rarr; Cold Storage Packing &rarr; Out for Delivery &rarr; Delivered.
40. **Preloaded Demo Orders**: Pre-seeded demo tracking (`UF-84920`) with temperature sensor telemetry.

### 🍳 Recipes, Social & Engagement
41. **Culinary Recipe Cards**: Prep times, difficulty tags, calories, and servings.
42. **Detailed Recipe Modal**: Interactive ingredient checklist and step-by-step chef method.
43. **Special Offers Countdown Timer**: Live ticking Days, Hours, Minutes, Seconds countdown.
44. **Customer Testimonials Slider**: Carousel with autoplay, pause on hover, arrows, and dot indicators.
45. **Animated Number Counters**: Triggered when entering viewport using `IntersectionObserver`.
46. **Scroll Reveal Animations**: Smooth fade-in and slide-up effects as sections come into view.
47. **Interactive FAQs Accordion**: Expandable questions and answers on contact page.
48. **Interactive Google Maps Embed**: Clean styled distribution center map.

### 🔒 Forms & Authentication
49. **Contact Form Validation**: Real-time regex verification for email, phone, and required text.
50. **Newsletter Subscription**: Email validation with instant toast notification.
51. **Search Autocomplete Modal**: Search overlay with instant suggestion pill tags.
52. **Demo User Authentication**: Login / Register tabs with session state stored in `localStorage`.
53. **Password Visibility Toggle**: Show/hide password eye icon toggle in auth forms.
54. **Toast Notification System**: Custom alerts (success, error, warning, info) with auto-dismiss.

---

## 💻 How to Run Locally

### Option 1: Direct File Launch
Simply double-click `index.html` in your file explorer to open it in any modern browser (Chrome, Edge, Firefox, Safari).

### Option 2: Python Local Server
If Python is installed on your computer:
```bash
# Navigate to the project directory
cd union-foods

# Start Python HTTP server
python -m http.server 8000
```
Then open your browser at: `http://localhost:8000`

### Option 3: VS Code Live Server
1. Open the `union-foods` folder in VS Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` &rarr; click **Open with Live Server**.

---

## 🌐 Live Deployment Instructions

### Deploy to GitHub Pages
1. Open terminal in the `union-foods` folder:
   ```bash
   git init
   git add .
   git commit -m "Deploy Union Foods commercial website"
   ```
2. Create a new public repository on GitHub (e.g. `union-foods-website`).
3. Connect your remote repository and push:
   ```bash
   git remote add origin https://github.com/<your-username>/union-foods-website.git
   git branch -M main
   git push -u origin main
   ```
4. On GitHub, navigate to **Settings** &rarr; **Pages**.
5. Under **Branch**, select `main` and folder `/ (root)`, then click **Save**.
6. Your live website will be accessible at: `https://<your-username>.github.io/union-foods-website/`

### Deploy to Netlify (Drag & Drop in 30 Seconds)
1. Sign in to [Netlify](https://app.netlify.com).
2. Go to the **Sites** tab.
3. Drag and drop the `union-foods` folder directly onto the upload zone.
4. Netlify will instantly deploy your website with an SSL-secured production URL (e.g. `https://union-foods.netlify.app`).

---

## 📱 Cross-Device Responsiveness Checklist

- **Desktop (1440px and above)**: Full-width container max 1360px, 4-column product grid, expansive hero layout.
- **Laptop (1024px - 1439px)**: 3-column product grid, 4-column category grid, fluid navigation.
- **Tablet (768px - 1023px)**: 2-column product grid, slide-in mobile navigation drawer, collapsible footer.
- **Mobile (320px - 767px)**: Single column product layout, 2-column category cards, touch-optimized minimum 44px tap targets, zero horizontal scrolling.

---

## 📄 License & Attribution
&copy; 2026 Union Foods Corporation. Developed for professional assessment. Pure HTML5, CSS3, and Vanilla JavaScript implementation.
